// Cloud Run 版認証プラグイン（control=5/6）。
// API 契約は auth-cloudflare と同じ {user,pass} → {ok,token,kasc}。
// 秘匿データ記法は gs://<キー>（r2:// も移行用に読み替える）。
import { showLoginForm } from "../../auth-login-form.js";
import { t } from "../../i18n.js";

function normalizeProjectId(id) {
  return String(id).toUpperCase().replace(/[^A-Z0-9]/g, "_");
}

function extractProjectId(url) {
  const m = /\/projects\/([^/]+)\/[^/?#]*\.kasc(?:[?#].*)?$/.exec(url);
  return m ? decodeURIComponent(m[1]) : null;
}

// .kasc 内の gs://<キー> / r2://<キー> を /api/data/<キー>?token=... に変換する
// GCS には gs:// 形式のまま保存し、配信時にだけ書き換える
function rewriteKascText(text, token) {
  return text.replace(/(?:gs|r2):\/\/([^|\s]+)/g, (_, key) => {
    const path = key.split("/").map(encodeURIComponent).join("/");
    return `/api/data/${path}?token=${encodeURIComponent(token)}`;
  });
}

// 保存前の正規化: 書き換え後の URL を gs:// 形式に戻す
function restoreKascText(text) {
  return text.replace(/\/api\/data\/([^?\s|]+)\?token=[^|\s]*/g, (_, path) => {
    const key = path.split("/").map(decodeURIComponent).join("/");
    return `gs://${key}`;
  });
}

function patchFetch(kascMap, token) {
  const originalFetch = window.fetch;
  window.fetch = async (input, init) => {
    let url = input;
    if (typeof input !== "string") {
      if (input && typeof input.url === "string") url = input.url;
      else if (input && typeof input.href === "string") url = input.href;
      else url = String(input);
    }
    const projectId = typeof url === "string" ? extractProjectId(url) : null;
    if (projectId) {
      const key = normalizeProjectId(projectId);
      if (!Object.prototype.hasOwnProperty.call(kascMap, key)) {
        return new Response("", { status: 404, statusText: "Not in store" });
      }
      const text = token ? rewriteKascText(kascMap[key], token) : kascMap[key];
      return new Response(text, { status: 200, headers: { "Content-Type": "text/plain" } });
    }
    return originalFetch(input, init);
  };
}

export async function authenticate() {
  return showLoginForm({
    onSubmit: async ({ user, pass }) => {
      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user, pass })
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.ok) {
        throw new Error(data.error || t("auth.failed"));
      }
      if (data.kasc && typeof data.kasc === "object") {
        patchFetch(data.kasc, data.token);
      }
      return {
        token: data.token || "",
        serverKasc: true,
        user: { name: user, role: "cloudrun" },
        updateKasc: (projectId, text) => {
          if (data.kasc) data.kasc[normalizeProjectId(projectId)] = text;
        },
        restoreKasc: restoreKascText
      };
    }
  });
}
