import * as THREE from "three";

const Cesium = window.Cesium;

const urlParams = new URLSearchParams(window.location.search);
// カメラ情報はハッシュ(#latitude=...)に置く。ハッシュはアドレスバーで書き換えても
// ページが再読み込みされないため、前のビューからそのままFLYTOできる(Google Earth と同じ挙動)
const initialCameraSource = window.location.search + window.location.hash;
const DEFAULT_VIEW = { latitude: 35.6852, longitude: 139.7528, height: 2000, pitch: -30, heading: 0 };

const viewer = new Cesium.Viewer("cesium-container", {
  terrainProvider: new Cesium.EllipsoidTerrainProvider(),
  baseLayerPicker: false,
  geocoder: false,
  homeButton: false,
  sceneModePicker: false,
  navigationHelpButton: false,
  animation: false,
  timeline: false,
  fullscreenButton: false,
  vrButton: false,
  infoBox: false,
  selectionIndicator: false,
});

viewer.scene.globe.depthTestAgainstTerrain = true;
viewer.scene.globe.enableLighting = false;
viewer.imageryLayers.removeAll();
viewer.camera.percentageChanged = 0.05;

// リロード直後にデフォルトの地球全体ビューが見えるのを防ぐため、
// 前回のカメラ位置（なければURLの座標）へ描画開始前に同期的に即セットする
let lastCameraSearch = null;
try { lastCameraSearch = sessionStorage.getItem("lastCameraSearch"); } catch (e) {}
const lastCamera = lastCameraSearch ? parseUrlCamera(lastCameraSearch) : null;
const hasLastCamera = !!(lastCamera && Number.isFinite(lastCamera.latitude) && Number.isFinite(lastCamera.longitude));
{
  const startupCamera = hasLastCamera ? lastCamera : parseUrlCamera(initialCameraSource);
  if (Number.isFinite(startupCamera.latitude) && Number.isFinite(startupCamera.longitude)) flyTo(startupCamera, 0);
}

const basemaps = [];
let selectedBasemap = null;
const cameraPresets = [];
const layers = [];
const tileLayers = [];
const layerState = new Map();
let layerOrder = [];
const expandedLayerGroups = new Set();
let currentProjectId = urlParams.get("project") || "default";
let yahooAppId = "";
let terrainEnabled = true;
let undergroundTransparency = 0;
let undergroundDiveEnabled = true;
let undergroundBackgroundColor = Cesium.Color.BLACK;
let basemapDrape3DTiles = false;
let infoRequestId = 0;
let walkModeActive = false;
let flyHeight = 20;
let flySpeed = 30;
const flyPaths = [];
let flyPath = null;
let flyPathProperties = {};
let flyPathCoords = null;
let flyPathCumulativeDistances = [];
let flyPathDistance = 0;
let flyPathTargetDistance = null;
let flyPathLinePositions = [];
let flyPathEntity = null;
let flyPathRafId = null;
let flyPathActive = false;
let flyPathProgress = 0;
let flyRafId = null;
let flyLastTime = performance.now();
let drawModeActive = false;
let drawnPoints = [];
let drawLineEntity = null;
let isDrawing = false;
let lastRightDownTime = 0;
const activeClippingPlanes = { planes: [] };
const activeDataSources = [];
const vectorDataSources = [];
let vectorSearchData = null;
const activePrimitives = [];
const drapeTerrainSources = { dem: true, tiles3d: false };
const drapeLayers = { xyz: true, geojson: true };
let geojsonPrimitiveDrape = false;
const demSources = {
  reearth: {
    title: "Re:Earth Terrain (標高 / MSL, level 19)",
    url: "https://terrain.reearth.land/cesium-mesh/msl",
  },
  "reearth-ellipsoid": {
    title: "Re:Earth Terrain (楕円体高 / WGS84, level 19)",
    url: "https://terrain.reearth.land/cesium-mesh/ellipsoid",
  },
  terrarium: {
    title: "Terrarium DEM (AWS, level 15)",
    elevationData: "https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png",
    elevationDecoder: { rScaler: 256, gScaler: 1, bScaler: 1 / 256, offset: -32768 },
    tileSize: 256,
    maximumLevel: 15,
    attribution: "Mapzen Terrarium · AWS",
    attributionUrl: "https://registry.opendata.aws/terrain-tiles/",
  },
};
let selectedDemSource = "reearth-ellipsoid";
const DEFAULT_MAXIMUM_LEVEL = 25;

let threeRenderer;
let threeScene;
let threeCamera;
let threeModel;
let backendEnabled = false;

function parseLayerTitle(title) {
  const parts = title.split(/[\\/]/).map(part => part.trim()).filter(Boolean);
  return {
    title: parts.at(-1) || title,
    group: parts.slice(0, -1).join(" / "),
    exclusiveGroup: /[\\/]{2}/.test(title),
  };
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[c]));
}

function appendAttributionText(container, text) {
  const trimmed = text.trim();
  if (!trimmed) return;
  if (trimmed.startsWith("<")) {
    const wrapper = document.createElement("span");
    wrapper.innerHTML = trimmed;
    container.append(wrapper);
  } else {
    const span = document.createElement("span");
    span.textContent = ` ${trimmed}`;
    container.append(span);
  }
}

function updateMapAttribution() {
  const attribution = document.querySelector("#map-attribution");
  attribution.replaceChildren();
  if (selectedBasemap?.attribution) appendAttributionText(attribution, selectedBasemap.attribution);
  [...tileLayers, ...layers].forEach(item => {
    if (item.visible && item.attribution) appendAttributionText(attribution, item.attribution);
  });
}

async function detectBackend() {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 1000);
    const response = await fetch("./health", { signal: controller.signal, cache: "no-store" });
    clearTimeout(timeout);
    if (response.ok) {
      const data = await response.json().catch(() => ({}));
      backendEnabled = data?.name === "kasugai_canvas";
    }
  } catch {
    backendEnabled = false;
  }
}

function getProjectConfigUrl() {
  if (backendEnabled) {
    return `/api/projects/${encodeURIComponent(currentProjectId)}/config`;
  }
  return `./projects/${encodeURIComponent(currentProjectId)}/kasugai_canvas.kasc`;
}

function getProjectBaseUrl() {
  return `projects/${encodeURIComponent(currentProjectId || "default")}/`;
}

function resolveProjectUrl(url) {
  if (typeof url !== "string") return url;
  const trimmed = url.trim();
  if (!trimmed) return trimmed;
  if (/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(trimmed) || trimmed.startsWith("//")) return trimmed;
  if (trimmed.startsWith("/")) return trimmed;
  let path = trimmed;
  if (path.startsWith("./")) path = path.slice(2);
  const segments = path.split("/").filter(Boolean);
  const safeSegments = [];
  for (const segment of segments) {
    if (segment === "..") {
      if (safeSegments.length > 0) safeSegments.pop();
    } else if (segment !== ".") {
      safeSegments.push(segment);
    }
  }
  return getProjectBaseUrl() + safeSegments.join("/");
}

async function loadProjects() {
  let definitions = [];
  if (backendEnabled) {
    const response = await fetch("/api/projects");
    if (!response.ok) throw new Error(await response.text());
    definitions = await response.json();
  } else {
    try {
      const response = await fetch("./projects/projects.json", { cache: "no-store" });
      if (response.ok) definitions = await response.json();
    } catch {}
  }
  if (!definitions.length) definitions = [{ id: "default", title: "デフォルトプロジェクト" }];
  const select = document.querySelector("#project-select");
  select.replaceChildren();
  definitions.forEach(project => {
    const option = document.createElement("option");
    option.value = project.id;
    option.textContent = project.title || project.id;
    if (project.id === currentProjectId) option.selected = true;
    select.append(option);
  });
}

async function loadInspectorConfig() {
  try {
    const projectId = currentProjectId || "default";
    const staticUrl = `./projects/${encodeURIComponent(projectId)}/kasugai_canvas.kasc`;
    let text = "";
    try {
      const response = await fetch(staticUrl, { cache: "no-store" });
      if (response.ok) text = await response.text();
    } catch {}
    if (!text && backendEnabled) {
      const response = await fetch(getProjectConfigUrl());
      if (!response.ok) throw new Error(await response.text());
      text = await response.text();
    }
    if (!text) text = defaultConfig;
    document.querySelector("#inspector-input").value = text;
    applyInspector(text);
    setInspectorStatus("設定を読み込みました。");
  } catch (error) {
    console.error("設定の読み込みに失敗しました。", error);
    setInspectorStatus(`設定を読み込めません: ${error instanceof Error ? error.message : error}`, true);
  }
}

async function saveInspectorConfig() {
  if (!backendEnabled) return;
  const response = await fetch(getProjectConfigUrl(), {
    method: "PUT",
    headers: { "Content-Type": "text/plain; charset=utf-8" },
    body: document.querySelector("#inspector-input").value,
  });
  if (!response.ok) throw new Error(await response.text());
}

function updateInspectorFromLayerOrder() {
  const input = document.querySelector("#inspector-input");
  if (!input) return;
  const lines = input.value.split(/\r?\n/);
  const layerLineIndices = [];
  lines.forEach((line, index) => {
    const separator = line.indexOf(":");
    if (separator < 0) return;
    const layerType = line.slice(0, separator).toLowerCase().trim();
    if (["xyz", "3dtiles", "geojson", "layer"].includes(layerType)) layerLineIndices.push(index);
  });
  const orderedSourceLines = layerOrder.map(id => layerState.get(id)?.sourceLine).filter(Boolean);
  if (layerLineIndices.length !== orderedSourceLines.length) return;
  layerLineIndices.forEach((index, i) => { lines[index] = orderedSourceLines[i]; });
  input.value = lines.join("\n");
}

async function persistLayerOrder() {
  updateInspectorFromLayerOrder();
  await saveInspectorConfig();
}

function setInspectorStatus(message, isError = false) {
  const status = document.querySelector("#inspector-status");
  status.textContent = message;
  status.style.color = isError ? "#a82020" : "";
}

function flyTo(options = {}, duration = null) {
  const latitude = Number(options.latitude);
  const longitude = Number(options.longitude);
  if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) return;
  let height = Number(options.height);
  if (!Number.isFinite(height)) height = DEFAULT_VIEW.height;
  const ssec = viewer.scene.screenSpaceCameraController;
  const pitchInput = Number(options.pitch) || 0;
  let pitchDeg = ssec.enableTilt ? Math.min(90, pitchInput) : -90;
  if (ssec.enableTilt && pitchDeg < -85) {
    pitchDeg = -84.99;
  }
  const pitch = pitchDeg * Math.PI / 180;
  const heading = (Number(options.heading) || 0) * Math.PI / 180;
  const destination = Cesium.Cartesian3.fromDegrees(longitude, latitude, height);
  const orientation = { heading, pitch, roll: 0 };
  if (duration === 0) {
    viewer.camera.setView({ destination, orientation });
    return;
  }
  const flight = { destination, orientation };
  if (Number.isFinite(duration)) {
    flight.duration = duration;
  } else {
    // Google Earth 風: 距離に応じて時間を伸ばし、一度ズームアウトしてから降下する弧を描く
    const distance = Cesium.Cartesian3.distance(viewer.camera.position, destination);
    flight.duration = Math.min(7, 1.0 + Math.log2(1 + distance / 1000) * 0.35);
    if (distance > 20000) {
      const currentHeight = Cesium.Cartographic.fromCartesian(viewer.camera.position).height;
      const peak = Math.min(distance * 0.6, 4000000);
      if (peak > Math.max(currentHeight, height)) flight.maximumHeight = peak;
    }
  }
  viewer.camera.flyTo(flight);
}

// 検索座標の地形標高を事前に読み込んで返す（未読み込みタイルもダウンロードする）
async function sampleGroundHeight(lat, lng) {
  const carto = Cesium.Cartographic.fromDegrees(lng, lat);
  // 1. sampleTerrainMostDetailed で対象タイルを事前ダウンロードして正確な標高を得る
  try {
    if (viewer.terrainProvider && !(viewer.terrainProvider instanceof Cesium.EllipsoidTerrainProvider)) {
      const [result] = await Cesium.sampleTerrainMostDetailed(viewer.terrainProvider, [carto]);
      if (result && Number.isFinite(result.height)) return result.height;
    }
  } catch (e) { /* 取得失敗時は読み込み済みタイルにフォールバック */ }
  // 2. フォールバック: 読み込み済みタイルから取得
  try {
    const sampled = viewer.scene.globe.getHeight(carto);
    if (Number.isFinite(sampled)) return sampled;
  } catch (e) { /* ignore */ }
  return 0;
}

// 目的の座標（ピッチ-90で真下に見える地点）が画面中央に来るように、
// ピッチ・高さ・方位からカメラ位置を後退補正して flyTo する。
// height / pitch / heading を省略した場合は現在のカメラの値を使う
async function flyToFeature(lat, lng, options = {}) {
  const cartographic = Cesium.Cartographic.fromCartesian(viewer.camera.position);
  const currentHeight = cartographic ? cartographic.height : DEFAULT_VIEW.height;
  const currentPitchDeg = viewer.camera.pitch * 180 / Math.PI;
  const currentHeadingDeg = viewer.camera.heading * 180 / Math.PI;
  const height = Number.isFinite(options.height) ? options.height : currentHeight;
  let pitchDeg = Number.isFinite(options.pitch) ? options.pitch : currentPitchDeg;
  const headingDeg = Number.isFinite(options.heading) ? options.heading : currentHeadingDeg;

  // flyTo 側のピッチ補正と同じ値を先に適用して距離計算のズレを防ぐ
  const ssec = viewer.scene.screenSpaceCameraController;
  if (!ssec.enableTilt) pitchDeg = -90;
  else if (pitchDeg < -85) pitchDeg = -84.99;

  let cameraLat = lat;
  let cameraLng = lng;
  const pitchRad = Math.abs(pitchDeg) * Math.PI / 180;
  // 真下(-90°)に近い場合は補正不要
  if (Math.abs(pitchDeg) < 89 && pitchRad > 0.01) {
    // 検索座標の地形標高を事前読み込みし、地面からの相対高さで後退距離を計算する
    const groundHeight = await sampleGroundHeight(lat, lng);
    const relativeHeight = Math.max(0, height - groundHeight);
    const distance = relativeHeight / Math.tan(pitchRad);
    const headingRad = headingDeg * Math.PI / 180;
    const metersPerDegLat = 111320;
    const metersPerDegLng = 111320 * Math.cos(lat * Math.PI / 180);
    cameraLat = lat - (distance * Math.cos(headingRad)) / metersPerDegLat;
    cameraLng = lng - (distance * Math.sin(headingRad)) / (metersPerDegLng || 1);
  }
  flyTo({ latitude: cameraLat, longitude: cameraLng, height, pitch: pitchDeg, heading: headingDeg });
}

function extractLineStringCoordinates(geojson) {
  if (!geojson || typeof geojson !== "object") return [];
  const coords = [];
  const collect = (obj) => {
    if (!obj || typeof obj !== "object") return;
    if (obj.type === "LineString") {
      if (Array.isArray(obj.coordinates)) coords.push(...obj.coordinates);
    } else if (obj.type === "MultiLineString") {
      (obj.coordinates || []).forEach(line => { if (Array.isArray(line)) coords.push(...line); });
    } else if (obj.type === "Feature") {
      collect(obj.geometry);
    } else if (obj.type === "FeatureCollection" || Array.isArray(obj.features)) {
      (obj.features || []).forEach(collect);
    } else if (obj.type === "GeometryCollection" || Array.isArray(obj.geometries)) {
      (obj.geometries || []).forEach(collect);
    }
  };
  collect(geojson);
  return coords.filter(c => Array.isArray(c) && c.length >= 2 && Number.isFinite(c[0]) && Number.isFinite(c[1]));
}

function buildFlyPath(rawCoords) {
  if (!rawCoords.length) return { points: [], distances: [] };
  const points = rawCoords.map(([lng, lat, alt = 0]) => ({ longitude: lng, latitude: lat, altitude: alt, terrain: 0 }));
  const distances = [0];
  for (let i = 0; i < points.length - 1; i++) {
    const a = points[i];
    const b = points[i + 1];
    const dx = (b.longitude - a.longitude) * 111320 * Math.cos((a.latitude + b.latitude) * Math.PI / 360);
    const dy = (b.latitude - a.latitude) * 111320;
    const dz = (b.altitude - a.altitude);
    const segLen = Math.sqrt(dx * dx + dy * dy + dz * dz) || 0;
    distances.push(distances[distances.length - 1] + segLen);
  }
  return { points, distances };
}

async function loadFlyGeoJson(url) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`${response.status} ${response.statusText}`);
  const geojson = await response.json();
  const rawCoords = extractLineStringCoordinates(geojson);
  if (!rawCoords.length) throw new Error("LineString または MultiLineString が見つかりません");
  return { ...buildFlyPath(rawCoords), properties: geojson.properties || {} };
}

function buildFlyPathLinePositions(coords) {
  return coords.map(c => Cesium.Cartesian3.fromDegrees(c.longitude, c.latitude, c.altitude + (c.terrain || 0) + flyHeight));
}

function getFlyPathLinePositions() {
  if (!flyPathLinePositions.length) return [];
  const idx = Math.floor(flyPathProgress);
  if (idx < 0 || idx >= flyPathLinePositions.length) return flyPathLinePositions;
  const nextIdx = Math.min(idx + 1, flyPathLinePositions.length - 1);
  const t = flyPathProgress - idx;
  const a = flyPathLinePositions[idx];
  const b = flyPathLinePositions[nextIdx];
  if (t === 0 || !b) return flyPathLinePositions.slice(0, idx + 1);
  const current = new Cesium.Cartesian3(
    a.x + (b.x - a.x) * t,
    a.y + (b.y - a.y) * t,
    a.z + (b.z - a.z) * t
  );
  return [...flyPathLinePositions.slice(0, idx + 1), current];
}

function updateUrlFromCamera() {
  const c = Cesium.Cartographic.fromCartesian(viewer.camera.position);
  const lon = Number(c.longitude * 180 / Math.PI).toFixed(6);
  const lat = Number(c.latitude * 180 / Math.PI).toFixed(6);
  const pitch = Number(viewer.camera.pitch * 180 / Math.PI).toFixed(2);
  const heading = Number(viewer.camera.heading * 180 / Math.PI).toFixed(2);
  const height = Number(c.height).toFixed(1);
  const params = new URLSearchParams(window.location.search);
  ["latitude", "longitude", "height", "pitch", "heading"].forEach(key => params.delete(key));
  if (currentProjectId) params.set("project", currentProjectId);
  const hashParams = new URLSearchParams();
  hashParams.set("latitude", lat);
  hashParams.set("longitude", lon);
  hashParams.set("height", height);
  hashParams.set("pitch", pitch);
  hashParams.set("heading", heading);
  const search = params.toString();
  window.history.replaceState(null, "", `${window.location.pathname}${search ? `?${search}` : ""}#${hashParams.toString()}`);
}

function updateCameraInputs() {
  const cartographic = Cesium.Cartographic.fromCartesian(viewer.camera.position);
  document.querySelector("#camera-latitude").value = Number(cartographic.latitude * 180 / Math.PI).toFixed(6);
  document.querySelector("#camera-longitude").value = Number(cartographic.longitude * 180 / Math.PI).toFixed(6);
  document.querySelector("#camera-height").value = Number(cartographic.height).toFixed(1);
  document.querySelector("#camera-pitch").value = Number(viewer.camera.pitch * 180 / Math.PI).toFixed(2);
  document.querySelector("#camera-heading").value = Number(viewer.camera.heading * 180 / Math.PI).toFixed(2);
  const compass = document.querySelector("#compass-button");
  if (compass) compass.style.transform = `rotateZ(${-viewer.camera.heading * 180 / Math.PI}deg)`;
  updateUrlFromCamera();
}

function renderBasemapSelector() {
  const select = document.querySelector("#basemap-select");
  select.replaceChildren();
  const none = document.createElement("option");
  none.value = "";
  none.textContent = "ベースマップなし";
  select.append(none);
  basemaps.forEach(basemap => {
    const option = document.createElement("option");
    option.value = basemap.id;
    option.textContent = basemap.title;
    if (basemap.id === selectedBasemap?.id) option.selected = true;
    select.append(option);
  });
}

function renderPresets() {
  const container = document.querySelector("#camera-presets");
  container.replaceChildren();
  cameraPresets.forEach((preset, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = preset.title;
    button.dataset.preset = String(index);
    button.addEventListener("click", () => flyTo(preset));
    container.append(button);
  });
}

function getOrderedLayerItems() {
  return layerOrder.map(id => layerState.get(id)).filter(Boolean);
}

function getGroupLayerIds(groupKey) {
  const [groupName, exclusive] = groupKey.split("|");
  return getOrderedLayerItems()
    .filter(layer => (layer.group || "") === groupName && (layer.exclusiveGroup ? "exclusive" : "regular") === exclusive)
    .map(layer => layer.id);
}

function renderLayerList() {
  const list = document.querySelector("#layer-list");
  const groupedLayers = new Map();
  getOrderedLayerItems().forEach(layer => {
    const group = layer.group || "";
    const key = `${group}|${layer.exclusiveGroup ? "exclusive" : "regular"}`;
    if (!groupedLayers.has(key)) groupedLayers.set(key, { group, exclusive: !!layer.exclusiveGroup, layers: [] });
    groupedLayers.get(key).layers.push(layer);
  });
  list.innerHTML = [...groupedLayers.values()].map(({ group, exclusive, layers }) => {
    const groupKey = `${group}|${exclusive ? "exclusive" : "regular"}`;
    const groupId = `layer-group-${[...groupKey].map(character => character.charCodeAt(0).toString(16)).join("")}`;
    const groupInputId = `${groupId}-checkbox`;
    const groupChecked = layers.some(layer => layer.visible);
    return `
    <section class="layer-group${group ? " grouped" : ""}${exclusive ? " exclusive" : ""}" data-group-key="${escapeHtml(groupKey)}">
      ${group ? `<div class="layer-group-title" draggable="true"><button class="layer-group-toggle" type="button" aria-label="グループを展開・折りたたみ" aria-expanded="${expandedLayerGroups.has(groupKey)}">${expandedLayerGroups.has(groupKey) ? "▾" : "▸"}</button><input id="${groupInputId}" class="layer-group-checkbox" type="${exclusive ? "radio" : "checkbox"}" ${exclusive ? `name="${escapeHtml(groupInputId)}"` : ""} data-group-key="${escapeHtml(groupKey)}" ${groupChecked ? "checked" : ""}><label class="layer-group-label" for="${groupInputId}">${escapeHtml(group)}</label>${exclusive ? '<small class="exclusive-badge">Exclusive</small>' : ""}</div>` : ""}
      <div class="layer-group-children" id="${groupId}"${group && !expandedLayerGroups.has(groupKey) ? " hidden" : ""}>
        ${layers.map((layer, index) => {
          const inputId = `${groupId}-layer-${index}`;
          return `
        <label class="layer-row" for="${inputId}" draggable="true" data-layer-id="${escapeHtml(layer.id)}">
          <input id="${inputId}" type="${exclusive ? "radio" : "checkbox"}" ${exclusive ? `name="${escapeHtml(groupId)}"` : ""} data-layer-id="${escapeHtml(layer.id)}" data-group="${escapeHtml(layer.group || "")}" data-exclusive="${exclusive ? "true" : "false"}" ${layer.visible ? "checked" : ""}>
          <span>${escapeHtml(layer.title)}</span>
          <small>${escapeHtml(layer.status || (layer.type === "tile" ? "Tile" : layer.type))}</small>
        </label>`;
        }).join("")}
      </div>
    </section>`;
  }).join("");

  list.querySelectorAll(".layer-group-toggle").forEach(toggle => {
    toggle.addEventListener("click", () => {
      const group = toggle.closest(".layer-group");
      const children = group.querySelector(".layer-group-children");
      const groupKey = group.dataset.groupKey;
      const expanded = toggle.getAttribute("aria-expanded") === "true";
      toggle.setAttribute("aria-expanded", String(!expanded));
      toggle.textContent = expanded ? "▸" : "▾";
      children.hidden = expanded;
      if (expanded) expandedLayerGroups.delete(groupKey);
      else expandedLayerGroups.add(groupKey);
    });
  });

  list.querySelectorAll(".layer-group-checkbox").forEach(input => {
    input.addEventListener("change", () => {
      const group = [...groupedLayers.values()].find(item => `${item.group}|${item.exclusive ? "exclusive" : "regular"}` === input.dataset.groupKey);
      if (!group) return;
      if (group.exclusive) {
        group.layers.forEach(layer => { layer.visible = false; });
        if (input.checked) (group.layers.find(layer => layer.visible) || group.layers[0]).visible = true;
      } else {
        group.layers.forEach(layer => { layer.visible = input.checked; });
      }
      renderLayerList();
      refreshLayers();
    });
  });

  list.querySelectorAll(".layer-group-checkbox").forEach(input => {
    input.addEventListener("click", event => {
      if (input.type === "radio" && input.checked) {
        event.preventDefault();
        input.checked = false;
        input.dispatchEvent(new Event("change"));
      }
    });
  });

  list.querySelectorAll(".layer-row input").forEach(input => {
    input.addEventListener("change", () => {
      const layer = layerState.get(input.dataset.layerId);
      if (!layer) return;
      layer.visible = input.checked;
      if (input.checked && input.dataset.exclusive === "true") {
        getOrderedLayerItems().forEach(other => {
          if (other !== layer && other.group === layer.group && other.exclusiveGroup) other.visible = false;
        });
      }
      renderLayerList();
      refreshLayers();
    });
  });

  let draggedId;
  let draggedGroupKey;

  list.querySelectorAll(".layer-group").forEach(groupSection => {
    groupSection.addEventListener("dragover", event => {
      if (!draggedGroupKey || draggedGroupKey === groupSection.dataset.groupKey) return;
      event.preventDefault();
      event.dataTransfer.dropEffect = "move";
    });
    groupSection.addEventListener("drop", event => {
      if (!draggedGroupKey) return;
      event.preventDefault();
      const sourceKey = draggedGroupKey;
      const targetKey = groupSection.dataset.groupKey;
      if (sourceKey === targetKey) return;
      const sourceIds = getGroupLayerIds(sourceKey);
      const targetIds = getGroupLayerIds(targetKey);
      const sourceFirstIndex = layerOrder.indexOf(sourceIds[0]);
      const targetFirstIndex = layerOrder.indexOf(targetIds[0]);
      const nextOrder = layerOrder.filter(id => !sourceIds.includes(id));
      let insertIndex;
      if (sourceFirstIndex < targetFirstIndex) {
        insertIndex = nextOrder.indexOf(targetIds[targetIds.length - 1]) + 1;
      } else {
        insertIndex = nextOrder.indexOf(targetIds[0]);
      }
      nextOrder.splice(insertIndex, 0, ...sourceIds);
      layerOrder = nextOrder;
      draggedGroupKey = undefined;
      renderLayerList();
      refreshLayers();
      void persistLayerOrder().catch(error => { console.warn("レイヤー順の保存エラー:", error); });
    });
  });

  list.querySelectorAll(".layer-group-title").forEach(title => {
    title.addEventListener("dragstart", event => {
      const groupSection = title.closest(".layer-group");
      if (!groupSection) return;
      draggedGroupKey = groupSection.dataset.groupKey;
      event.dataTransfer.effectAllowed = "move";
      event.dataTransfer.setData("text/plain", draggedGroupKey);
      groupSection.classList.add("dragging");
    });
    title.addEventListener("dragend", () => {
      const groupSection = title.closest(".layer-group");
      if (groupSection) groupSection.classList.remove("dragging");
      draggedGroupKey = undefined;
    });
  });

  list.querySelectorAll(".layer-row").forEach(row => {
    row.addEventListener("dragstart", event => {
      draggedId = row.dataset.layerId;
      event.dataTransfer.effectAllowed = "move";
      event.dataTransfer.setData("text/plain", draggedId);
      row.classList.add("dragging");
    });
    row.addEventListener("dragend", () => { draggedId = undefined; row.classList.remove("dragging"); });
    row.addEventListener("dragover", event => {
      if (!draggedId) return;
      event.preventDefault();
      event.dataTransfer.dropEffect = "move";
    });
    row.addEventListener("drop", event => {
      if (!draggedId) return;
      event.preventDefault();
      const sourceId = draggedId || event.dataTransfer.getData("text/plain");
      const targetId = row.dataset.layerId;
      if (!sourceId || sourceId === targetId) return;
      const orderedLayers = getOrderedLayerItems();
      const sourceLayer = orderedLayers.find(item => item.id === sourceId);
      const targetLayer = orderedLayers.find(item => item.id === targetId);
      if (!sourceLayer || !targetLayer || sourceLayer.group !== targetLayer.group || (sourceLayer.exclusiveGroup ? "exclusive" : "regular") !== (targetLayer.exclusiveGroup ? "exclusive" : "regular")) return;
      const nextOrder = orderedLayers.map(item => item.id);
      const sourceIndex = nextOrder.indexOf(sourceId);
      const targetIndex = nextOrder.indexOf(targetId);
      if (sourceIndex < 0 || targetIndex < 0) return;
      nextOrder.splice(sourceIndex, 1);
      nextOrder.splice(nextOrder.indexOf(targetId), 0, sourceId);
      layerOrder = nextOrder;
      renderLayerList();
      refreshLayers();
      void persistLayerOrder().catch(error => { console.warn("レイヤー順の保存エラー:", error); });
    });
  });

  list.querySelectorAll(".layer-group-checkbox").forEach(input => {
    const group = [...groupedLayers.values()].find(item => `${item.group}|${item.exclusive ? "exclusive" : "regular"}` === input.dataset.groupKey);
    if (group && !group.exclusive) input.indeterminate = group.layers.some(layer => layer.visible) && group.layers.some(layer => !layer.visible);
  });
}

function renderFlyPathSelect() {
  const select = document.querySelector("#fly-path-select");
  if (!select) return;
  const current = select.value;
  select.innerHTML = '<option value="__manual__">手動</option>' +
    flyPaths.map((path, index) => `<option value="${index}">${escapeHtml(path.title)}</option>`).join("");
  const exists = [...select.options].some(option => option.value === current);
  select.value = exists ? current : "__manual__";
}

async function ensureDrawnRouteFlyPath() {
  if (!backendEnabled) return;
  const project = currentProjectId || "";
  const listUrl = `/api/files?project=${encodeURIComponent(project)}`;
  try {
    const listResponse = await fetch(listUrl);
    if (!listResponse.ok) return;
    const files = await listResponse.json();
    const routeFiles = files.filter(name => /^drawn_route_\d+\.geojson$/.test(name)).sort();
    const fileUrls = new Set(flyPaths.map(path => path.url));
    let changed = false;
    for (const file of routeFiles) {
      const fileUrl = `/api/file?path=${encodeURIComponent(file)}&project=${encodeURIComponent(project)}`;
      if (fileUrls.has(fileUrl)) continue;
      const match = file.match(/^drawn_route_(\d+)\.geojson$/);
      const title = `描画ルート${match[1]}`;
      flyPaths.push({ title, url: fileUrl, speed: 30, height: 0, pitch: -10, loop: false, step: 100 });
      changed = true;
    }
    for (let i = flyPaths.length - 1; i >= 0; i--) {
      const p = flyPaths[i];
      const match = p.url.match(/[?&]path=([^&]+)/);
      if (!match) continue;
      const file = decodeURIComponent(match[1]);
      if (p.title.startsWith("描画ルート") && !routeFiles.includes(file)) {
        flyPaths.splice(i, 1);
        changed = true;
      }
    }
    if (changed) renderFlyPathSelect();
  } catch (error) {
    // ファイルの存在確認に失敗しても無視
  }
}

function formatTileUrl(template, index) {
  return template
    .replaceAll("{z}", String(index.z))
    .replaceAll("{x}", String(index.x))
    .replaceAll("{y}", String(index.y));
}

class TerrariumTerrainProvider {
  constructor(options) {
    this.tilingScheme = new Cesium.GeographicTilingScheme();
    this.heightmapWidth = options.tileSize || 256;
    this.heightmapHeight = options.tileSize || 256;
    this.hasVertexNormals = false;
    this.hasWaterMask = false;
    this.elevationData = proxyTemplateUrl(options.elevationData);
    this.elevationDecoder = options.elevationDecoder;
    this.maximumLevel = options.maximumLevel || 15;
    this.availability = {
      isTileAvailable: (level, x, y) => level <= this.maximumLevel && x >= 0 && y >= 0,
    };
  }

  getLevelMaximumGeometricError(level) {
    return 156543.03392 / (1 << level);
  }

  requestTileGeometry(x, y, level, request) {
    if (level > this.maximumLevel) return Promise.reject(new Error("Tile out of range"));
    const url = formatTileUrl(this.elevationData, { x, y, z: level });
    return fetch(url, { mode: "cors" })
      .then(async response => {
        if (!response.ok) throw new Error(`Terrain tile request failed (${response.status}): ${url}`);
        return createImageBitmap(await response.blob());
      })
      .then(bitmap => {
        const canvas = document.createElement("canvas");
        canvas.width = this.heightmapWidth;
        canvas.height = this.heightmapHeight;
        const ctx = canvas.getContext("2d", { willReadFrequently: true });
        if (!ctx) throw new Error("Terrain sample canvas is unavailable");
        ctx.imageSmoothingEnabled = false;
        ctx.drawImage(bitmap, 0, 0, this.heightmapWidth, this.heightmapHeight);
        bitmap.close();
        const image = ctx.getImageData(0, 0, this.heightmapWidth, this.heightmapHeight);
        const { rScaler, gScaler, bScaler, offset } = this.elevationDecoder;
        const count = this.heightmapWidth * this.heightmapHeight;
        const heights = new Float32Array(count);
        for (let i = 0; i < count; i += 1) {
          const offsetPixels = i * 4;
          const r = image.data[offsetPixels];
          const g = image.data[offsetPixels + 1];
          const b = image.data[offsetPixels + 2];
          heights[i] = r * rScaler + g * gScaler + b * bScaler + offset;
        }
        return new Cesium.HeightmapTerrainData({
          buffer: heights,
          width: this.heightmapWidth,
          height: this.heightmapHeight,
          childTileMask: level === this.maximumLevel ? 0 : 15,
          structure: {
            heightScale: 1.0,
            heightOffset: 0.0,
            elementsPerHeight: 1,
            stride: 1,
            elementMultiplier: 1.0,
            isBigEndian: false,
          },
        });
      });
  }
}

function toHex(str) {
  return Array.from(new TextEncoder().encode(str), b => b.toString(16).padStart(2, "0")).join("");
}

function proxyTileUrl(url, useProxy = true) {
  if (typeof url !== "string" || !url.startsWith("http")) return url;
  if (!backendEnabled || useProxy === false) return url;
  const origin = window.location.origin;
  if (url.startsWith(origin + "/api/tile/")) return url;
  let dir = url;
  let file = "";
  if (!dir.endsWith("/")) {
    const lastSlash = dir.lastIndexOf("/");
    const candidate = dir.slice(lastSlash + 1);
    if (candidate.includes(".")) {
      file = candidate;
      dir = dir.slice(0, lastSlash + 1);
    } else {
      dir += "/";
    }
  }
  const hex = toHex(dir);
  if (file) return `${origin}/api/tile/${hex}/${file}`;
  return `${origin}/api/tile/${hex}/`;
}

function proxyTemplateUrl(url, useProxy = true) {
  if (typeof url !== "string" || !url.startsWith("http")) return url;
  if (!backendEnabled || useProxy === false) return url;
  if (url.startsWith(window.location.origin)) return url;
  const encoded = encodeURIComponent(url).replace(/%7B/g, "{").replace(/%7D/g, "}");
  return `${window.location.origin}/api/tile?url=${encoded}`;
}

function createUrlTemplateProvider(options) {
  return new Cesium.UrlTemplateImageryProvider({
    url: proxyTemplateUrl(options.url, options.proxy !== false),
    credit: new Cesium.Credit(options.attribution || ""),
    maximumLevel: options.maximumLevel || DEFAULT_MAXIMUM_LEVEL,
    tileWidth: options.tileSize || 256,
    tileHeight: options.tileSize || 256,
  });
}

function createClippingPlaneFromEnu(normalEnu) {
  const center = viewer.camera.position.clone();
  const transform = Cesium.Transforms.eastNorthUpToFixedFrame(center);
  const normalEcef = Cesium.Matrix4.multiplyByPointAsVector(transform, normalEnu, new Cesium.Cartesian3());
  Cesium.Cartesian3.normalize(normalEcef, normalEcef);
  const distance = -Cesium.Cartesian3.dot(normalEcef, center);
  return new Cesium.ClippingPlane(normalEcef, distance);
}

function applyClippingPlanes(target) {
  try {
    if (!activeClippingPlanes.planes.length) {
      target.clippingPlanes = undefined;
      return;
    }
    target.clippingPlanes = new Cesium.ClippingPlaneCollection({
      planes: activeClippingPlanes.planes.map(p => new Cesium.ClippingPlane(p.normal, p.distance)),
      edgeWidth: 2,
      edgeColor: Cesium.Color.RED,
      enabled: true,
    });
  } catch (error) {
    console.warn("クリッピング平面の適用に失敗しました:", error);
  }
}

function updateUndergroundView() {
  const alpha = 1 - undergroundTransparency;
  viewer.scene.globe.translucency.frontFaceAlpha = alpha;
  viewer.scene.globe.translucency.backFaceAlpha = alpha;
  viewer.scene.globe.undergroundColor = undergroundBackgroundColor;
  viewer.scene.globe.undergroundColorAlphaByDistance = undefined;
  viewer.scene.backgroundColor = undergroundBackgroundColor;
  if (viewer.scene.skyBox) {
    viewer.scene.skyBox.show = undergroundTransparency === 0 && !undergroundDiveEnabled;
  }
  if (undergroundDiveEnabled) {
    viewer.scene.screenSpaceCameraController.enableCollisionDetection = false;
  } else {
    viewer.scene.screenSpaceCameraController.enableCollisionDetection = true;
    viewer.scene.screenSpaceCameraController.minimumZoomDistance = 1;
  }
}

function updateEffectSettings() {
  const hasTerrain = !(viewer.terrainProvider instanceof Cesium.EllipsoidTerrainProvider);
  const terrainLightingInput = document.querySelector("#effect-terrain-lighting");
  const translucencyInput = document.querySelector("#effect-translucency");
  const fogInput = document.querySelector("#effect-fog");
  const skyAtmosphereInput = document.querySelector("#effect-sky-atmosphere");
  const shadowsInput = document.querySelector("#effect-shadows");
  const depthTestInput = document.querySelector("#effect-depth-test");

  viewer.scene.globe.enableLighting = terrainLightingInput?.checked ?? false;
  viewer.scene.shadows = shadowsInput?.checked ?? false;
  viewer.scene.globe.depthTestAgainstTerrain = (depthTestInput?.checked ?? true) && hasTerrain && undergroundTransparency === 0;
  viewer.scene.globe.translucency.enabled = translucencyInput?.checked ?? false;
  if (viewer.scene.fog) viewer.scene.fog.enabled = fogInput?.checked ?? true;
  if (viewer.scene.skyAtmosphere) viewer.scene.skyAtmosphere.show = skyAtmosphereInput?.checked ?? true;
}

function getCesiumTilesetOptions() {
  const sseInput = document.querySelector("#cesium-sse");
  const memoryInput = document.querySelector("#cesium-max-memory");
  const sse = sseInput ? Number(sseInput.value) : 16;
  const maximumMemoryUsage = memoryInput ? Number(memoryInput.value) : 2048;
  return {
    maximumScreenSpaceError: Number.isFinite(sse) && sse >= 0 ? sse : 16,
    maximumMemoryUsage: Number.isFinite(maximumMemoryUsage) && maximumMemoryUsage >= 0 ? maximumMemoryUsage : 2048,
    dynamicScreenSpaceError: document.querySelector("#cesium-dynamic-sse")?.checked ?? false,
    cullWithChildrenBounds: document.querySelector("#cesium-cull-children")?.checked ?? true,
    preferLeaves: document.querySelector("#cesium-prefer-leaves")?.checked ?? false,
    skipLevelOfDetail: document.querySelector("#cesium-skip-lod")?.checked ?? true,
  };
}

function cartesianToDegrees(cartesian) {
  try {
    const c = Cesium.Cartographic.fromCartesian(cartesian);
    return { lat: c.latitude * 180 / Math.PI, lng: c.longitude * 180 / Math.PI };
  } catch (e) { return null; }
}

function getEntityPosition(entity) {
  try {
    const time = viewer.clock && viewer.clock.currentTime;
    if (entity.position) {
      const pos = entity.position.getValue(time);
      if (pos) return pos;
    }
    if (entity.polygon) {
      const hierarchy = entity.polygon.hierarchy.getValue(time);
      const positions = hierarchy && hierarchy.positions;
      if (positions && positions.length) {
        let sum = new Cesium.Cartesian3(0, 0, 0);
        for (const p of positions) sum = Cesium.Cartesian3.add(sum, p, sum);
        return Cesium.Cartesian3.divideByScalar(sum, positions.length, new Cesium.Cartesian3());
      }
    }
    if (entity.polyline) {
      const positions = entity.polyline.positions.getValue(time);
      if (positions && positions.length) {
        let sum = new Cesium.Cartesian3(0, 0, 0);
        for (const p of positions) sum = Cesium.Cartesian3.add(sum, p, sum);
        return Cesium.Cartesian3.divideByScalar(sum, positions.length, new Cesium.Cartesian3());
      }
    }
  } catch (e) {}
  return null;
}

function buildVectorSearchIndex() {
  vectorSearchData = { all: { attributes: [], valuesByAttr: {}, featureByAttr: {} }, layers: {}, layerOptions: [] };
  const time = viewer.clock && viewer.clock.currentTime;
  const allAttrSet = new Set();
  const allValuesMap = {};
  const allFeatureMap = {};
  for (const { ds, id, title } of vectorDataSources) {
    const layerInfo = { title, attributes: [], valuesByAttr: {}, featureByAttr: {} };
    const attrSet = new Set();
    const valuesMap = {};
    const featureMap = {};
    try {
      for (const entity of ds.entities.values) {
        const props = (entity.properties && entity.properties.getValue) ? entity.properties.getValue(time) : (entity.properties || {});
        if (!props) continue;
        for (const key of Object.keys(props)) {
          const raw = props[key];
          if (raw == null || raw === "") continue;
          const val = (typeof raw === "object") ? JSON.stringify(raw) : String(raw);
          attrSet.add(key);
          if (!valuesMap[key]) valuesMap[key] = new Set();
          if (!valuesMap[key].has(val)) {
            valuesMap[key].add(val);
            if (!featureMap[key]) featureMap[key] = {};
            if (!featureMap[key][val]) {
              const cartesian = getEntityPosition(entity);
              const deg = cartesian ? cartesianToDegrees(cartesian) : null;
              if (deg && Number.isFinite(deg.lat) && Number.isFinite(deg.lng)) {
                featureMap[key][val] = deg;
                if (!allFeatureMap[key]) allFeatureMap[key] = {};
                if (!allFeatureMap[key][val]) allFeatureMap[key][val] = deg;
              }
            }
          }
        }
      }
    } catch (e) {}
    layerInfo.attributes = [...attrSet].sort((a, b) => a.localeCompare(b));
    for (const attr of layerInfo.attributes) {
      layerInfo.valuesByAttr[attr] = [...valuesMap[attr]].sort((a, b) => a.localeCompare(b));
      layerInfo.featureByAttr[attr] = featureMap[attr] || {};
    }
    vectorSearchData.layers[id] = layerInfo;
    if (layerInfo.attributes.length) {
      vectorSearchData.layerOptions.push({ id, title });
    }
    for (const attr of layerInfo.attributes) {
      allAttrSet.add(attr);
      if (!allValuesMap[attr]) allValuesMap[attr] = new Set();
      for (const val of layerInfo.valuesByAttr[attr]) allValuesMap[attr].add(val);
    }
  }
  vectorSearchData.all.attributes = [...allAttrSet].sort((a, b) => a.localeCompare(b));
  for (const attr of vectorSearchData.all.attributes) {
    vectorSearchData.all.valuesByAttr[attr] = [...allValuesMap[attr]].sort((a, b) => a.localeCompare(b));
    vectorSearchData.all.featureByAttr[attr] = allFeatureMap[attr] || {};
  }
}

function getCurrentVectorSource() {
  try {
    if (!vectorSearchData) return null;
    const layerSelect = document.querySelector("#vector-layer");
    const layerId = layerSelect ? layerSelect.value : "__all__";
    if (layerId === "__all__") return vectorSearchData.all || null;
    return (vectorSearchData.layers && vectorSearchData.layers[layerId]) || null;
  } catch (e) { return null; }
}

function updateVectorSearchUI() {
  const layerSelect = document.querySelector("#vector-layer");
  const attrSelect = document.querySelector("#vector-attr");
  const valueSelect = document.querySelector("#vector-value");
  const flyBtn = document.querySelector("#vector-fly-btn");
  const status = document.querySelector("#vector-search-status");
  const data = vectorSearchData;
  if (!layerSelect) return;
  const opts = (data && data.layerOptions) || [];
  let html = '<option value="__all__">全選択</option>';
  for (const o of opts) {
    html += '<option value="' + escapeHtml(String(o.id)) + '">' + escapeHtml(o.title || o.id) + '</option>';
  }
  layerSelect.innerHTML = html;
  layerSelect.disabled = (opts.length === 0);
  if (attrSelect) {
    attrSelect.innerHTML = '<option value="__all__">全選択</option>';
    attrSelect.disabled = true;
  }
  if (valueSelect) {
    valueSelect.innerHTML = '<option value="">値を選択</option>';
    valueSelect.disabled = true;
  }
  if (flyBtn) flyBtn.disabled = true;
  if (status) status.textContent = (data && data.all && data.all.attributes.length) ? (data.all.attributes.length + " 属性を読み込みました") : "属性付きベクトルがありません";
  if (layerSelect && !layerSelect.disabled) {
    try { layerSelect.dispatchEvent(new Event("change")); } catch (e) {}
  }
}

async function refreshLayers() {
  viewer.imageryLayers.removeAll(false);
  vectorDataSources.forEach(({ ds }) => { try { viewer.dataSources.remove(ds, false); } catch (error) { /* ignore */ } });
  vectorDataSources.length = 0;
  activeDataSources.length = 0;
  activePrimitives.forEach(primitive => { try { viewer.scene.primitives.remove(primitive); } catch (error) { /* ignore */ } });
  activePrimitives.length = 0;

  const demSource = terrainEnabled ? demSources[selectedDemSource] : null;
  if (demSource?.url) {
    const terrainUrl = proxyTileUrl(demSource.url);
    try {
      const terrainProvider = Cesium.CesiumTerrainProvider.fromUrl
        ? await Cesium.CesiumTerrainProvider.fromUrl(terrainUrl)
        : await new Promise((resolve, reject) => {
            const provider = new Cesium.CesiumTerrainProvider({ url: terrainUrl });
            if (!provider.readyPromise) {
              reject(new Error("CesiumTerrainProvider.readyPromise is unavailable"));
            } else {
              provider.readyPromise.then(() => resolve(provider)).catch(reject);
            }
          });
      viewer.terrainProvider = terrainProvider;
    } catch (error) {
      console.warn("DEM の読み込みに失敗しました:", error);
      viewer.terrainProvider = new Cesium.EllipsoidTerrainProvider();
    }
  } else if (demSource?.elevationData) {
    try {
      viewer.terrainProvider = new TerrariumTerrainProvider(demSource);
    } catch (error) {
      console.warn("Terrarium DEM の初期化に失敗しました:", error);
      viewer.terrainProvider = new Cesium.EllipsoidTerrainProvider();
    }
  } else {
    viewer.terrainProvider = new Cesium.EllipsoidTerrainProvider();
  }

  const visible3DTiles = layers.some(l => l.visible && l.type === "3dtiles");
  const drape3DTiles = drapeTerrainSources.tiles3d && visible3DTiles;
  const orderedItems = getOrderedLayerItems();
  const orderedTileLayers = orderedItems.filter(layer => layer.type === "tile").slice().reverse();
  const orderedOtherLayers = orderedItems.filter(layer => layer.type === "3dtiles" || layer.type === "geojson" || layer.type === "layer").slice().reverse();

  // 3D Tiles ドレープ用プロバイダー定義
  const drapeProviders = [];
  if (drape3DTiles) {
    if (basemapDrape3DTiles && selectedBasemap?.url) {
      drapeProviders.push({
        url: selectedBasemap.url,
        attribution: selectedBasemap.attribution,
        maximumLevel: selectedBasemap.maximumLevel || DEFAULT_MAXIMUM_LEVEL,
        tileSize: selectedBasemap.tileSize || 256,
        opacity: selectedBasemap.opacity ?? 1.0,
        proxy: selectedBasemap.proxy,
      });
    }
    if (drapeLayers.xyz) {
      orderedTileLayers.filter(t => t.visible).forEach(item => {
        drapeProviders.push({
          url: item.url,
          attribution: item.attribution,
          maximumLevel: item.maximumLevel || DEFAULT_MAXIMUM_LEVEL,
          tileSize: item.tileSize || 256,
          opacity: item.opacity ?? 0.8,
          proxy: item.proxy,
        });
      });
    }
  }

  // Globe 表面のベースマップ
  if (selectedBasemap?.url) {
    try {
      const provider = createUrlTemplateProvider({
        url: selectedBasemap.url,
        attribution: selectedBasemap.attribution,
        maximumLevel: selectedBasemap.maximumLevel || DEFAULT_MAXIMUM_LEVEL,
        tileSize: selectedBasemap.tileSize || 256,
      });
      viewer.imageryLayers.add(new Cesium.ImageryLayer(provider, { alpha: selectedBasemap.opacity ?? 1.0 }));
    } catch (error) {
      console.warn("ベースマップの作成に失敗しました:", error);
    }
  }

  // Globe 表面の XYZ
  for (const item of orderedTileLayers) {
    if (!item.visible) continue;
    if ((drapeTerrainSources.dem || drape3DTiles) && (!drapeLayers.xyz || !drapeTerrainSources.dem)) continue;
    try {
      const provider = createUrlTemplateProvider({
        url: item.url,
        attribution: item.attribution,
        maximumLevel: item.maximumLevel || DEFAULT_MAXIMUM_LEVEL,
        tileSize: item.tileSize || 256,
      });
      viewer.imageryLayers.add(new Cesium.ImageryLayer(provider, { alpha: item.opacity ?? 0.8 }));
    } catch (error) {
      console.warn("XYZ タイルの作成に失敗しました:", item.url, error);
    }
  }

  // 3D Tiles / GeoJSON
  for (const item of orderedOtherLayers) {
    if (!item.visible && item.type === "3dtiles") continue;
    if (item.type === "3dtiles") {
      try {
        const tileset = await Cesium.Cesium3DTileset.fromUrl(proxyTileUrl(item.url, item.proxy), getCesiumTilesetOptions());
        if (drape3DTiles && Array.isArray(drapeProviders) && drapeProviders.length > 0) {
          drapeProviders.forEach(options => {
            try {
              const provider = createUrlTemplateProvider(options);
              const imageryLayer = new Cesium.ImageryLayer(provider, { alpha: options.opacity ?? 0.8 });
              tileset.imageryLayers.add(imageryLayer);
            } catch (drapeError) {
              console.warn("3D Tiles ドレープレイヤー追加失敗:", options.url, drapeError);
            }
          });
        }
        applyClippingPlanes(tileset);
        viewer.scene.primitives.add(tileset);
        activePrimitives.push(tileset);
      } catch (error) {
        console.warn("3D Tiles の読み込みに失敗しました:", item.url, error);
      }
    } else if (item.type === "geojson" || item.type === "layer") {
      try {
        const clamp = drapeLayers.geojson && (drapeTerrainSources.dem || drape3DTiles);
        if (!clamp && !item.visible) continue;
        if (clamp && geojsonPrimitiveDrape && Cesium.GeoJsonPrimitive) {
          let heightReference = Cesium.HeightReference.CLAMP_TO_GROUND;
          if (drapeTerrainSources.dem && drape3DTiles) heightReference = Cesium.HeightReference.CLAMP_TO_GROUND;
          else if (drape3DTiles) heightReference = Cesium.HeightReference.CLAMP_TO_3D_TILE;
          else if (drapeTerrainSources.dem) heightReference = Cesium.HeightReference.CLAMP_TO_TERRAIN;
          const primitive = await Cesium.GeoJsonPrimitive.fromUrl(item.url, { heightReference, scene: viewer.scene });
          primitive.show = item.visible;
          viewer.scene.primitives.add(primitive);
          activePrimitives.push(primitive);
          continue;
        }
        let classification;
        if (clamp) {
          if (drapeTerrainSources.dem && drape3DTiles) classification = Cesium.ClassificationType.BOTH;
          else if (drape3DTiles) classification = Cesium.ClassificationType.CESIUM_3D_TILE;
          else if (drapeTerrainSources.dem) classification = Cesium.ClassificationType.TERRAIN;
        }
        const ds = await Cesium.GeoJsonDataSource.load(item.url, { clampToGround: clamp });
        for (const entity of ds.entities.values) {
          if (entity.polygon) {
            entity.polygon.outline = new Cesium.ConstantProperty(false);
            if (clamp) entity.polygon.classificationType = new Cesium.ConstantProperty(classification);
          }
          if (entity.polyline) {
            if (clamp) {
              entity.polyline.clampToGround = new Cesium.ConstantProperty(true);
              entity.polyline.classificationType = new Cesium.ConstantProperty(classification);
            }
          }
        }
        try { ds.show = item.visible; } catch (e) {}
        await viewer.dataSources.add(ds);
        vectorDataSources.push({ ds, id: item.id, title: item.title });
      } catch (error) {
        console.warn("GeoJSON の読み込みに失敗しました:", item.url, error);
      }
    }
  }

  applyClippingPlanes(viewer.scene.globe);
  updateUndergroundView();
  updateEffectSettings();
  buildVectorSearchIndex();
  updateVectorSearchUI();
  updateMapAttribution();
}

function setupInfoTabs(content) {
  const buttons = [...content.querySelectorAll(".tab-button")];
  const panels = [...content.querySelectorAll(".tab-content")];
  if (!buttons.length || !panels.length) return;
  const activate = index => {
    buttons.forEach((button, i) => button.classList.toggle("active", i === index));
    panels.forEach((panel, i) => {
      panel.classList.toggle("active", i === index);
      panel.hidden = i !== index;
    });
  };
  buttons.forEach((button, index) => button.addEventListener("click", () => activate(index)));
  activate(Math.max(0, buttons.findIndex(button => button.classList.contains("active"))));
}

async function loadInfoContent(url) {
  const content = document.querySelector("#info-content");
  if (!content) return;
  const requestId = ++infoRequestId;
  content.replaceChildren();
  if (!url) return;
  try {
    const infoUrl = backendEnabled ? `/api/info?url=${encodeURIComponent(url)}` : url;
    const response = await fetch(infoUrl, { mode: "cors" });
    if (!response.ok) throw new Error(await response.text());
    const html = await response.text();
    if (requestId !== infoRequestId) return;
    const documentFragment = new DOMParser().parseFromString(html, "text/html");
    documentFragment.querySelectorAll("script, iframe, object, embed, form, link, style").forEach(node => node.remove());
    documentFragment.querySelectorAll("*").forEach(node => {
      [...node.attributes].forEach(attribute => {
        if (/^on/i.test(attribute.name) || /javascript:/i.test(attribute.value)) node.removeAttribute(attribute.name);
      });
    });
    content.replaceChildren(...[...documentFragment.body.childNodes].map(node => document.importNode(node, true)));
    setupInfoTabs(content);
  } catch (error) {
    if (requestId === infoRequestId) content.textContent = `INFOを読み込めません: ${error instanceof Error ? error.message : error}`;
  }
}

function updateSearchProvider() {
  const searchProvider = document.querySelector("#search-provider");
  const searchYahooWarning = document.querySelector("#search-yahoo-warning");
  if (!searchProvider) return;
  const yahooOpt = searchProvider.querySelector('option[value="yahoo"]');
  const hasYahoo = yahooAppId && !yahooAppId.includes("あなたのYahoo");
  if (yahooOpt) yahooOpt.disabled = !hasYahoo;
  if (!hasYahoo && searchProvider.value === "yahoo") searchProvider.value = "gsi";
  if (searchYahooWarning) searchYahooWarning.style.display = (searchProvider.value === "yahoo") ? "" : "none";
}

function applyInspector(text) {
  const nextLines = text.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
  const parsedCameras = [];
  const parsedBasemaps = [];
  layerState.clear();
  tileLayers.splice(0, tileLayers.length);
  layers.splice(0, layers.length);
  basemaps.splice(0, basemaps.length);
  layerOrder = [];
  flyPaths.splice(0, flyPaths.length);
  flyPath = null;
  flyPathCoords = null;
  flyPathLinePositions = [];
  if (flyPathEntity) { viewer.entities.remove(flyPathEntity); flyPathEntity = null; }
  flyPathActive = false;
  flyPathProgress = 0;

  document.body.style.background = "";
  undergroundBackgroundColor = Cesium.Color.BLACK;
  ++infoRequestId;
  document.querySelector("#info-content").replaceChildren();
  document.querySelector("#legend-panel img").removeAttribute("src");

  let inspectorLayerIndex = 0;
  nextLines.forEach(line => {
    const separator = line.indexOf(":");
    if (separator < 0) return;
    const type = line.slice(0, separator).toLowerCase();
    const value = line.slice(separator + 1).trim();

    if (type === "background") {
      document.body.style.background = value;
      const baseColor = Cesium.Color.fromCssColorString(value);
      if (baseColor) {
        viewer.scene.globe.baseColor = baseColor;
        undergroundBackgroundColor = baseColor;
      }
    }
    if (type === "yahooappid") {
      yahooAppId = value;
      updateSearchProvider();
    }
    if (type === "info") {
      void loadInfoContent(resolveProjectUrl(value));
    }
    if (type === "legend") {
      const parts = value.split("|").map(part => part.trim());
      document.querySelector("#legend-panel img").src = resolveProjectUrl(parts[parts.length - 1]);
    }

    if (type === "base") {
      const parts = value.split("|").map(part => part.trim());
      if (parts[0] && parts[1]) {
        const options = {};
        parts.slice(3).forEach(part => {
          const eq = part.indexOf("=");
          if (eq < 0) return;
          const key = part.slice(0, eq).trim();
          const raw = part.slice(eq + 1).trim();
          const number = Number(raw);
          if (key === "tileSize" && [256, 512].includes(number)) options.tileSize = number;
          if ((key === "maximumLevel" || key === "maxZoom") && Number.isInteger(number) && number >= 0) options.maximumLevel = number;
          if (key === "opacity" && Number.isFinite(number)) options.opacity = Math.max(0, Math.min(1, number));
          if (key === "proxy" && /^(off|false|direct)$/i.test(raw)) options.proxy = false;
        });
        parsedBasemaps.push({
          id: `inspector-base-${parsedBasemaps.length}`,
          title: parts[0],
          url: resolveProjectUrl(parts[1]),
          attribution: parts[2] && !/^(on|off|true|false)$/i.test(parts[2]) ? parts[2] : "",
          tileSize: options.tileSize || 256,
          opacity: options.opacity ?? 1.0,
          proxy: options.proxy !== false,
          ...(options.maximumLevel === undefined ? {} : { maximumLevel: options.maximumLevel }),
        });
      }
    }

    if (type === "cam") {
      const parts = value.split("|").map(part => part.trim());
      if (parts.length < 3) return;
      const camera = { title: parts[0], latitude: Number(parts[1]), longitude: Number(parts[2]), pitch: -30, heading: 0 };
      parts.slice(3).forEach(part => {
        const [key, raw] = part.split("=");
        const number = Number(raw);
        if ((key === "p" || key === "pitch") && Number.isFinite(number)) camera.pitch = number;
        if ((key === "d" || key === "heading") && Number.isFinite(number)) camera.heading = number;
        if ((key === "h" || key === "height") && Number.isFinite(number)) camera.height = number;
      });
      if (Number.isFinite(camera.latitude) && Number.isFinite(camera.longitude)) parsedCameras.push(camera);
    }

    if (type === "fly_geojson") {
      const parts = value.split("|").map(part => part.trim());
      const title = parts[0];
      const url = resolveProjectUrl(parts[1]);
      if (!url) return;
      const config = { title: title || url, url, speed: 30, height: 0, pitch: -10, loop: false, step: 100 };
      const off = parts.some(part => /^(off|false)$/i.test(part));
      parts.slice(2).forEach(part => {
        const eq = part.indexOf("=");
        if (eq < 0) return;
        const key = part.slice(0, eq).trim().toLowerCase();
        const raw = part.slice(eq + 1).trim();
        const number = Number(raw);
        if ((key === "speed" || key === "s") && Number.isFinite(number) && number > 0) config.speed = number;
        if ((key === "height" || key === "h") && Number.isFinite(number)) config.height = number;
        if ((key === "pitch" || key === "p") && Number.isFinite(number)) config.pitch = number;
        if ((key === "step") && Number.isFinite(number) && number > 0) config.step = number;
        if (key === "loop" || key === "l") config.loop = /^(true|1|on|yes)$/i.test(raw);
      });
      if (!off) flyPaths.push(config);
    }

    if (type === "xyz") {
      const parts = value.split("|").map(part => part.trim());
      const title = parts[0];
      const url = resolveProjectUrl(parts[1]);
      const off = parts.some(part => /^(off|false)$/i.test(part));
      if (!title || !url) return;
      const { group, title: displayTitle, exclusiveGroup } = parseLayerTitle(title);
      const options = {};
      parts.slice(3).forEach(part => {
        const eq = part.indexOf("=");
        if (eq < 0) return;
        const key = part.slice(0, eq).trim();
        const raw = part.slice(eq + 1).trim();
        const number = Number(raw);
        if (key === "opacity" && Number.isFinite(number)) options.opacity = Math.max(0, Math.min(1, number));
        if ((key === "maximumLevel" || key === "maxZoom") && Number.isInteger(number) && number >= 0) options.maximumLevel = number;
        if (key === "tileSize" && [256, 512].includes(number)) options.tileSize = number;
        if (key === "proxy" && /^(off|false|direct)$/i.test(raw)) options.proxy = false;
      });
      const id = `inspector-layer-${inspectorLayerIndex++}`;
      const item = { id, title: displayTitle, sourceTitle: title, sourceLine: line, url, visible: !off, type: "tile", opacity: options.opacity ?? 0.8, attribution: parts[2] && !/^(on|off|true|false)$/i.test(parts[2]) ? parts[2] : "", proxy: options.proxy !== false, group, exclusiveGroup };
      if (options.maximumLevel !== undefined) item.maximumLevel = options.maximumLevel;
      if (options.tileSize !== undefined) item.tileSize = options.tileSize;
      tileLayers.push(item);
      layerState.set(id, item);
      layerOrder.push(id);
    }

    if (type === "3dtiles" || type === "geojson" || type === "layer") {
      const parts = value.split("|").map(part => part.trim());
      const title = parts[0];
      const url = resolveProjectUrl(parts[1]);
      const off = parts.some(part => /^(off|false)$/i.test(part));
      const proxy = !parts.some(part => /^proxy\s*=\s*(off|false|direct)$/i.test(part));
      if (!title) return;
      const { group, title: displayTitle, exclusiveGroup } = parseLayerTitle(title);
      const id = `inspector-layer-${inspectorLayerIndex++}`;
      const item = { id, title: displayTitle, sourceTitle: title, sourceLine: line, type, url, visible: !off, attribution: parts[2] && !/^(on|off|true|false)$/i.test(parts[2]) ? parts[2] : "", proxy, group, exclusiveGroup };
      layers.push(item);
      layerState.set(id, item);
      layerOrder.push(id);
    }
  });

  basemaps.splice(0, basemaps.length, ...parsedBasemaps);
  selectedBasemap = basemaps[0] || null;
  cameraPresets.splice(0, cameraPresets.length, ...parsedCameras);
  const uniqueFlyPaths = [...new Map(flyPaths.map(path => [path.url, path])).values()];
  flyPaths.splice(0, flyPaths.length, ...uniqueFlyPaths);
  renderBasemapSelector();
  renderPresets();
  renderLayerList();
  renderFlyPathSelect();
  void ensureDrawnRouteFlyPath();
  refreshLayers();
  updateSearchProvider();
}

function setupThreeJs() {
  const container = document.querySelector("#cesium-container");
  const canvas = document.createElement("canvas");
  canvas.id = "three-canvas";
  canvas.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:1;";
  container.append(canvas);

  threeRenderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
  threeRenderer.autoClear = false;
  threeRenderer.setPixelRatio(window.devicePixelRatio);
  const resize = () => {
    if (!viewer?.canvas) return;
    threeRenderer.setSize(viewer.canvas.clientWidth, viewer.canvas.clientHeight, false);
  };
  resize();
  window.addEventListener("resize", resize);

  threeScene = new THREE.Scene();
  threeScene.add(new THREE.HemisphereLight(0xffffff, 0x668080, 2.2));
  threeModel = new THREE.Mesh(
    new THREE.BoxGeometry(1, 1, 1),
    new THREE.MeshStandardMaterial({ color: 0x168f84, roughness: 0.6, metalness: 0.1 }),
  );
  const modelPosition = Cesium.Cartesian3.fromDegrees(0, 0, 18);
  threeModel.position.set(modelPosition.x, modelPosition.y, modelPosition.z);
  threeModel.scale.setScalar(10000);
  threeModel.rotation.y = 0.6;
  threeScene.add(threeModel);

  threeCamera = new THREE.Camera();
  threeCamera.matrixAutoUpdate = false;

  viewer.scene.postRender.addEventListener(() => {
    if (!threeRenderer || !threeCamera) return;
    threeRenderer.state.reset();
    threeCamera.matrixWorldInverse.fromArray(viewer.camera.viewMatrix);
    threeCamera.matrixWorld.copy(threeCamera.matrixWorldInverse).invert();
    threeCamera.projectionMatrix.fromArray(viewer.camera.frustum.projectionMatrix);
    threeCamera.projectionMatrixInverse.copy(threeCamera.projectionMatrix).invert();
    threeRenderer.render(threeScene, threeCamera);
  });
}

function updateTopDownButton(is2D) {
  const topDownButton = document.querySelector("#top-down-button");
  if (!topDownButton) return;
  topDownButton.textContent = is2D ? "2D" : "3D";
  topDownButton.setAttribute("aria-label", is2D ? "2D top-down view" : "3D perspective view");
  topDownButton.setAttribute("title", is2D ? "2D top-down view" : "3D perspective view");
}

function setTopDown(is2D) {
  const ssec = viewer.scene.screenSpaceCameraController;
  ssec.enableTilt = !is2D;
  viewer.camera.constrainedAxis = is2D ? Cesium.Cartesian3.UNIT_Z : undefined;
  const c = Cesium.Cartographic.fromCartesian(viewer.camera.position);
  const pitchDeg = viewer.camera.pitch * 180 / Math.PI;
  flyTo({
    latitude: c.latitude * 180 / Math.PI,
    longitude: c.longitude * 180 / Math.PI,
    height: c.height,
    pitch: pitchDeg,
    heading: viewer.camera.heading * 180 / Math.PI,
  });
  updateTopDownButton(is2D);
}

function setupEvents() {
  document.querySelector("#basemap-select").addEventListener("change", event => {
    selectedBasemap = basemaps.find(b => b.id === event.target.value) || null;
    updateMapAttribution();
    refreshLayers();
  });

  document.querySelector("#apply-camera").addEventListener("click", () => {
    const next = {};
    ["longitude", "latitude", "height", "pitch", "heading"].forEach(key => {
      const value = Number(document.querySelector(`#camera-${key}`).value);
      if (Number.isFinite(value)) next[key] = value;
    });
    flyTo(next);
  });

  const searchProvider = document.querySelector("#search-provider");
  if (searchProvider) {
    searchProvider.addEventListener("change", () => {
      const searchYahooWarning = document.querySelector("#search-yahoo-warning");
      if (searchYahooWarning) searchYahooWarning.style.display = (searchProvider.value === "yahoo") ? "" : "none";
    });
  }
  updateSearchProvider();

  document.querySelector("#search-form").addEventListener("submit", async event => {
    event.preventDefault();
    const query = document.querySelector("#search-query").value.trim();
    const results = document.querySelector("#search-results");
    if (!query) {
      results.innerHTML = '<li style="padding:8px;color:#71818d;">検索語を入力してください。</li>';
      return;
    }
    results.innerHTML = '<li style="padding:8px;color:#71818d;">検索中...</li>';
    try {
      const provider = searchProvider ? searchProvider.value : "gsi";
      let useYahoo = provider === "yahoo" && yahooAppId && !yahooAppId.includes("あなたのYahoo");
      if (!backendEnabled) useYahoo = false;
      let response;
      if (backendEnabled) {
        const params = new URLSearchParams({ query });
        if (useYahoo) params.set("appid", yahooAppId);
        response = await fetch(`/api/search?${params}`);
      } else {
        response = await fetch(`https://msearch.gsi.go.jp/address-search/AddressSearch?q=${encodeURIComponent(query)}`, { mode: "cors" });
      }
      if (!response.ok) throw new Error(await response.text() || `検索に失敗しました (${response.status})`);
      const data = await response.json();
      const items = useYahoo
        ? (data.Feature || []).map(item => ({
            title: item.Name || item.name || "",
            address: item.Property?.Address || item.Property?.address || "",
            latitude: Number(item.Geometry?.Coordinates?.split(",")[1]),
            longitude: Number(item.Geometry?.Coordinates?.split(",")[0]),
          }))
        : data.map(item => ({
            title: item.properties?.title || item.properties?.name || item.properties?.Name || "",
            address: item.properties?.address || item.properties?.Address || item.properties?.title || "",
            latitude: Number(item.geometry?.coordinates?.[1]),
            longitude: Number(item.geometry?.coordinates?.[0]),
          }));
      const validItems = items.filter(item => Number.isFinite(item.latitude) && Number.isFinite(item.longitude));
      if (!validItems.length) {
        results.innerHTML = '<li style="padding:8px;color:#71818d;">該当する結果がありません。</li>';
        return;
      }
      results.innerHTML = validItems.map((item, index) => `
        <li style="padding:0;border-bottom:1px solid #e4ecef;">
          <button type="button" data-search-index="${index}" style="width:100%;padding:6px 8px;border:0;background:transparent;cursor:pointer;text-align:left;">
            <span style="display:block;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escapeHtml(item.title)}</span>
            <span style="display:block;font-size:0.85em;color:#52636d;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escapeHtml(item.address)}</span>
          </button>
        </li>
      `).join("");
      results.querySelectorAll("[data-search-index]").forEach(button => {
        button.addEventListener("click", () => {
          const item = validItems[Number(button.dataset.searchIndex)];
          flyToFeature(item.latitude, item.longitude);
        });
      });
    } catch (error) {
      results.innerHTML = `<li style="padding:8px;color:#a82020;">${escapeHtml(error instanceof Error ? error.message : "検索に失敗しました。")}</li>`;
    }
  });

  document.querySelector("#terrain-toggle").addEventListener("change", event => {
    terrainEnabled = event.target.checked;
    refreshLayers();
  });

  document.querySelector("#dem-source").addEventListener("change", event => {
    selectedDemSource = event.target.value;
    terrainEnabled = true;
    document.querySelector("#terrain-toggle").checked = true;
    refreshLayers();
  });

  document.querySelector("#basemap-drape-3dtiles").addEventListener("change", event => {
    basemapDrape3DTiles = event.target.checked;
    refreshLayers();
  });

  document.querySelector("#drape-terrain-dem").addEventListener("change", event => {
    drapeTerrainSources.dem = event.target.checked;
    refreshLayers();
  });

  document.querySelector("#drape-terrain-tiles3d").addEventListener("change", event => {
    drapeTerrainSources.tiles3d = event.target.checked;
    refreshLayers();
  });

  document.querySelector("#drape-xyz").addEventListener("change", event => {
    drapeLayers.xyz = event.target.checked;
    refreshLayers();
  });

  document.querySelector("#drape-geojson").addEventListener("change", event => {
    drapeLayers.geojson = event.target.checked;
    refreshLayers();
  });

  document.querySelector("#drape-geojson-primitive")?.addEventListener("change", event => {
    geojsonPrimitiveDrape = event.target.checked;
    refreshLayers();
  });

  ["#effect-terrain-lighting", "#effect-translucency", "#effect-fog", "#effect-sky-atmosphere", "#effect-shadows", "#effect-depth-test"].forEach(selector => {
    document.querySelector(selector)?.addEventListener("change", () => updateEffectSettings());
  });

  const transparencyInput = document.querySelector("#underground-transparency");
  const transparencyValue = document.querySelector("#underground-transparency-value");
  transparencyInput.addEventListener("input", event => {
    undergroundTransparency = Number(event.target.value);
    if (transparencyValue) transparencyValue.textContent = `${Math.round(undergroundTransparency * 100)}%`;
    updateUndergroundView();
    updateEffectSettings();
  });

  const undergroundDiveToggle = document.querySelector("#underground-dive-toggle");
  undergroundDiveToggle.checked = undergroundDiveEnabled;
  undergroundDiveToggle.addEventListener("change", event => {
    undergroundDiveEnabled = event.target.checked;
    updateUndergroundView();
  });

  ["#cesium-sse", "#cesium-max-memory"].forEach(selector => {
    document.querySelector(selector).addEventListener("change", () => refreshLayers());
  });

  ["#cesium-dynamic-sse", "#cesium-cull-children", "#cesium-prefer-leaves", "#cesium-skip-lod"].forEach(selector => {
    document.querySelector(selector).addEventListener("change", () => refreshLayers());
  });

  function setClipStatus(message, isError = false) {
    const status = document.querySelector("#clip-status");
    status.textContent = message;
    status.style.color = isError ? "#a82020" : "";
  }

  function applyClip(type) {
    const normals = {
      ns: new Cesium.Cartesian3(1, 0, 0),
      ew: new Cesium.Cartesian3(0, 1, 0),
      h: new Cesium.Cartesian3(0, 0, 1),
    };
    const normal = normals[type];
    if (!normal) {
      activeClippingPlanes.planes = [];
      refreshLayers();
      setClipStatus("クリッピングを解除しました。");
      return;
    }
    try {
      activeClippingPlanes.planes = [createClippingPlaneFromEnu(normal)];
      refreshLayers();
      setClipStatus(`${type.toUpperCase()} 断面を適用しました。`);
    } catch (error) {
      setClipStatus(`断面作成エラー: ${error.message}`, true);
    }
  }

  document.querySelector("#clip-ns").addEventListener("click", () => applyClip("ns"));
  document.querySelector("#clip-ew").addEventListener("click", () => applyClip("ew"));
  document.querySelector("#clip-h").addEventListener("click", () => applyClip("h"));
  document.querySelector("#clip-clear").addEventListener("click", () => applyClip("clear"));

  document.querySelector("#compass-button").addEventListener("click", () => {
    const c = Cesium.Cartographic.fromCartesian(viewer.camera.position);
    flyTo({
      latitude: c.latitude * 180 / Math.PI,
      longitude: c.longitude * 180 / Math.PI,
      height: c.height,
      pitch: viewer.camera.pitch * 180 / Math.PI,
      heading: 0,
    });
  });

  document.querySelector("#top-down-button").addEventListener("click", () => {
    setTopDown(viewer.scene.screenSpaceCameraController.enableTilt);
  });

  function getBearing(a, b) {
    const lat1 = a.latitude * Math.PI / 180;
    const lat2 = b.latitude * Math.PI / 180;
    const dLng = (b.longitude - a.longitude) * Math.PI / 180;
    const x = Math.sin(dLng) * Math.cos(lat2);
    const y = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
    return Math.atan2(x, y);
  }
  function lerpBearing(a, b, t) {
    let diff = b - a;
    while (diff <= -Math.PI) diff += 2 * Math.PI;
    while (diff > Math.PI) diff -= 2 * Math.PI;
    return a + diff * t;
  }
  function updateFlyPathCamera(distance) {
    const path = flyPathCoords;
    const total = flyPathCumulativeDistances[flyPathCumulativeDistances.length - 1] || 0;
    let flyDistance = distance;
    if (flyDistance > total) flyDistance = total;
    if (flyDistance < 0) flyDistance = 0;

    let idx = 0;
    while (idx + 1 < flyPathCumulativeDistances.length && flyDistance >= flyPathCumulativeDistances[idx + 1]) idx++;
    const nextIdx = Math.min(idx + 1, path.length - 1);
    const segDist = (flyPathCumulativeDistances[nextIdx] - flyPathCumulativeDistances[idx]) || 1;
    const t = (flyDistance - flyPathCumulativeDistances[idx]) / segDist;
    const a = path[idx];
    const b = path[nextIdx];
    flyPathProgress = idx + t;
    const lat = a.latitude + (b.latitude - a.latitude) * t;
    const lng = a.longitude + (b.longitude - a.longitude) * t;
    const alt = a.altitude + (b.altitude - a.altitude) * t;
    const terrain = (a.terrain || 0) + ((b.terrain || 0) - (a.terrain || 0)) * t;
    const height = alt + terrain + flyHeight;
    let heading = getBearing(a, b);
    if (nextIdx + 1 < path.length) {
      const nextBearing = getBearing(path[nextIdx], path[nextIdx + 1]);
      const remaining = (1 - t) * segDist;
      const blendStart = Math.min(segDist, 100);
      const blend = remaining < blendStart ? 1 - (remaining / blendStart) : 0;
      heading = lerpBearing(heading, nextBearing, blend);
    }
    const pitch = Math.max(-85, Math.min(0, flyPath.pitch)) * Math.PI / 180;

    try {
      viewer.camera.setView({
        destination: Cesium.Cartesian3.fromDegrees(lng, lat, height),
        orientation: { heading, pitch, roll: 0 },
      });
      viewer.scene.requestRender();
    } catch (error) {
      console.error("flyPathLoop setView error:", error);
    }

    if (walkOffsetEl && document.activeElement !== walkOffsetEl) walkOffsetEl.value = flyHeight.toFixed(1);
    if (walkTerrainEl) walkTerrainEl.textContent = (alt + flyHeight).toFixed(1);
    if (walkTerrainLabelEl) walkTerrainLabelEl.textContent = "地上高（AGL）";
    if (walkSpeedEl && document.activeElement !== walkSpeedEl) walkSpeedEl.value = flySpeed.toFixed(1);
    if (walkPitchEl && document.activeElement !== walkPitchEl) walkPitchEl.value = (pitch * 180 / Math.PI).toFixed(1);
  }
  function getTargetVertexDistance(direction) {
    if (!flyPathCoords || flyPathCoords.length < 2 || !flyPathCumulativeDistances.length) return null;
    const total = flyPathCumulativeDistances[flyPathCumulativeDistances.length - 1] || 0;
    if (direction > 0) {
      if (flyPathDistance >= total - 0.001) return null;
      return total;
    }
    if (flyPathDistance <= 0.001) return null;
    return 0;
  }
  function pauseFlyPath() {
    if (flyPathRafId !== null) {
      cancelAnimationFrame(flyPathRafId);
      flyPathRafId = null;
    }
    flyPathActive = false;
  }
  function toggleFlyPathDirection(direction) {
    if (!flyPathCoords || flyPathCoords.length < 2) return;
    if (flyPathActive && flyPathTargetDistance !== null) {
      const movingForward = flyPathTargetDistance > flyPathDistance;
      const movingBackward = flyPathTargetDistance < flyPathDistance;
      if ((direction > 0 && movingForward) || (direction < 0 && movingBackward)) {
        pauseFlyPath();
        return;
      }
    }
    const target = getTargetVertexDistance(direction);
    if (target === null) return;
    flyPathTargetDistance = target;
    if (walkRafId !== null) {
      cancelAnimationFrame(walkRafId);
      walkRafId = null;
    }
    if (flyPathRafId === null) {
      flyPathActive = true;
      flyPathLastTime = performance.now();
      flyPathRafId = requestAnimationFrame(flyPathLoop);
    }
  }

  function stopFlyPath() {
    flyPathActive = false;
    flyPathTargetDistance = null;
    if (flyPathRafId !== null) {
      cancelAnimationFrame(flyPathRafId);
      flyPathRafId = null;
    }
    if (flyPathEntity) {
      viewer.entities.remove(flyPathEntity);
      flyPathEntity = null;
    }
    flyPath = null;
    flyPathProperties = {};
    flyPathCoords = null;
    flyPathCumulativeDistances = [];
    flyPathDistance = 0;
    flyPathProgress = 0;
    flyPathLinePositions = [];
    updateFlyPointEditor();
  }

  async function startFlyPath(index) {
    if (!Number.isFinite(index) || index < 0 || index >= flyPaths.length) return;
    if (flyPathRafId !== null) {
      cancelAnimationFrame(flyPathRafId);
      flyPathRafId = null;
    }
    flyPath = flyPaths[index];
    try {
      const pathData = await loadFlyGeoJson(flyPath.url);
      flyPathCoords = pathData.points;
      flyPathCumulativeDistances = pathData.distances;
      flyPathProperties = pathData.properties || {};
    } catch (error) {
      console.error("Fly GeoJSON の読み込みに失敗しました:", error);
      flyPathCoords = null;
      flyPathCumulativeDistances = [];
      flyPathProperties = {};
      flyPathActive = false;
      return;
    }
    if (!flyPathCoords || !flyPathCoords.length) return;
    flySpeed = Number.isFinite(flyPath.speed) ? Number(flyPath.speed) : 30;
    flyHeight = Number.isFinite(flyPath.height) ? Number(flyPath.height) : 0;
    if (walkSpeedEl) walkSpeedEl.value = flySpeed.toFixed(1);
    if (walkOffsetEl) walkOffsetEl.value = flyHeight.toFixed(1);
    if (!flyPathCoords || !flyPathCoords.length) return;
    for (const point of flyPathCoords) {
      const carto = Cesium.Cartographic.fromDegrees(point.longitude, point.latitude);
      point.terrain = carto ? (viewer.scene.globe.getHeight(carto) ?? 0) : 0;
    }
    flyPathLinePositions = buildFlyPathLinePositions(flyPathCoords);
    if (flyPathEntity) viewer.entities.remove(flyPathEntity);
    flyPathEntity = viewer.entities.add({
      polyline: {
        positions: new Cesium.CallbackProperty(() => getFlyPathLinePositions(), false),
        width: 4,
        material: new Cesium.PolylineGlowMaterialProperty({ color: Cesium.Color.YELLOW, glowPower: 0.15 }),
      },
    });
    flyPathProgress = 0;
    flyPathDistance = 0;
    flyPathTargetDistance = null;
    flyPathActive = false;
    if (flyPathRafId !== null) {
      cancelAnimationFrame(flyPathRafId);
      flyPathRafId = null;
    }
    updateFlyPathCamera(0);
    updateFlyPointEditor();
  }

  let flyPathLastTime = performance.now();
  const flyPathLoop = (timestamp) => {
    flyPathRafId = null;
    if (!flyPathActive || !flyPathCoords || !flyPathCoords.length) return;
    try {
      const delta = Math.min((timestamp - flyPathLastTime) / 1000, 0.1);
      flyPathLastTime = timestamp;
      applyWalkKeys(delta);

      const total = flyPathCumulativeDistances[flyPathCumulativeDistances.length - 1] || 0;
      if (flyPathTargetDistance !== null) {
        const stepMeters = Math.abs(flySpeed / 3.6) * delta;
        const diff = flyPathTargetDistance - flyPathDistance;
        if (Math.abs(diff) <= stepMeters) {
          flyPathDistance = flyPathTargetDistance;
          flyPathTargetDistance = null;
          flyPathActive = false;
        } else {
          flyPathDistance += Math.sign(diff) * stepMeters;
          if (flyPathDistance > total) flyPathDistance = total;
          if (flyPathDistance < 0) flyPathDistance = 0;
        }
        updateFlyPathCamera(flyPathDistance);
      } else {
        const stepMeters = (flySpeed / 3.6) * delta;
        flyPathDistance += stepMeters;
        if (flyPathDistance > total) {
          if (flyPath.loop) {
            flyPathDistance = total > 0 ? flyPathDistance % total : 0;
          } else {
            flyPathDistance = total;
            updateFlyPathCamera(flyPathDistance);
            stopFlyPath();
            return;
          }
        }
        if (flyPathDistance < 0) {
          if (flyPath.loop && total > 0) {
            flyPathDistance = (total + (flyPathDistance % total)) % total;
          } else {
            flyPathDistance = 0;
            updateFlyPathCamera(flyPathDistance);
            stopFlyPath();
            return;
          }
        }

        updateFlyPathCamera(flyPathDistance);
      }

      if (flyPathActive) flyPathRafId = requestAnimationFrame(flyPathLoop);
    } catch (error) {
      console.error("flyPathLoop error:", error);
      stopFlyPath();
    }
  };

  const modeSelect = document.querySelector("#mode-select");
  const walkOffsetEl = document.querySelector("#walk-offset");
  const walkTerrainEl = document.querySelector("#walk-terrain");
  const walkTerrainLabelEl = document.querySelector("#walk-terrain-label");
  const walkSpeedEl = document.querySelector("#walk-speed");
  const walkPitchEl = document.querySelector("#walk-pitch");
  const flyPresetSelect = document.querySelector("#fly-preset-select");
  const flyPointEditor = document.querySelector("#fly-point-editor");
  const flyPointIndexEl = document.querySelector("#fly-point-index");
  const flyPointOffsetEl = document.querySelector("#fly-point-offset");
  const flyPointSaveEl = document.querySelector("#fly-point-save");
  const flyReverseBtn = document.querySelector("#fly-reverse-btn");
  const walkKeys = new Set();
  function updateFlyPointEditor() {
    if (!flyPointEditor || !flyPointIndexEl || !flyPointOffsetEl) return;
    if (!flyPathCoords || !flyPathCoords.length) {
      flyPointEditor.style.display = "none";
      return;
    }
    flyPointEditor.style.display = "";
    const currentIndex = Math.min(Math.max(0, Math.round(flyPathProgress) || 0), flyPathCoords.length - 1);
    flyPointIndexEl.innerHTML = "";
    for (let i = 0; i < flyPathCoords.length; i++) {
      const option = document.createElement("option");
      option.value = String(i);
      option.textContent = String(i + 1);
      if (i === currentIndex) option.selected = true;
      flyPointIndexEl.appendChild(option);
    }
    const point = flyPathCoords[currentIndex];
    flyPointOffsetEl.value = Number.isFinite(point.altitude) ? point.altitude.toFixed(1) : "0.0";
  }
  async function saveFlyPointOffsets() {
    if (!flyPathCoords || !flyPath || !flyPath.url) return;
    if (!flyPath.url.startsWith("/api/file")) {
      console.warn("ローカルファイル以外のルートは保存できません");
      return;
    }
    const coordinates = flyPathCoords.map(p => [p.longitude, p.latitude, Number.isFinite(p.altitude) ? p.altitude : 0]);
    const properties = Object.keys(flyPathProperties || {}).length ? flyPathProperties : { heightReference: "Terrain", heightOffset: 20 };
    const geojson = {
      type: "Feature",
      properties,
      geometry: { type: "LineString", coordinates }
    };
    try {
      const response = await fetch(flyPath.url, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(geojson) });
      if (!response.ok) throw new Error(await response.text());
      console.log("点の高さを保存しました");
    } catch (error) {
      console.error("点の高さの保存に失敗しました:", error);
    }
  }
  function applyWalkKeys(delta) {
    if (!flyPathCoords || flyPathCoords.length < 2) return;
    const total = flyPathCumulativeDistances[flyPathCumulativeDistances.length - 1] || 0;

    const heightChange = (walkKeys.has("KeyQ") ? 1 : 0) - (walkKeys.has("KeyE") ? 1 : 0);
    if (heightChange !== 0) {
      flyHeight += 10 * heightChange * delta;
      if (flyPathCoords) flyPathLinePositions = buildFlyPathLinePositions(flyPathCoords);
    }

    const speedChange = (walkKeys.has("Equal") || walkKeys.has("NumpadAdd") ? 1 : 0) -
      (walkKeys.has("Minus") || walkKeys.has("NumpadSubtract") ? 1 : 0);
    if (speedChange !== 0) {
      flySpeed += 20 * speedChange * delta;
      if (flySpeed < 0) flySpeed = 0;
    }

    const pitchChange = (walkKeys.has("ArrowUp") ? 1 : 0) - (walkKeys.has("ArrowDown") ? 1 : 0);
    if (pitchChange !== 0 && flyPath) {
      flyPath.pitch += 20 * pitchChange * delta;
      flyPath.pitch = Math.max(-85, Math.min(0, flyPath.pitch));
    }

    const manualDirection = (walkKeys.has("KeyW") ? 1 : 0) - (walkKeys.has("KeyS") ? 1 : 0);
    if (manualDirection > 0) {
      flyPathTargetDistance = total;
    } else if (manualDirection < 0) {
      flyPathTargetDistance = 0;
    }
  }
  if (walkOffsetEl) {
    walkOffsetEl.addEventListener("input", () => {
      const value = Number(walkOffsetEl.value);
      if (!Number.isFinite(value)) {
        walkOffsetEl.value = flyHeight.toFixed(1);
        return;
      }
      flyHeight = value;
      if (flyPathActive && flyPath) flyPathLinePositions = buildFlyPathLinePositions(flyPathCoords);
      if (flyPresetSelect) flyPresetSelect.value = "custom";
    });
  }
  if (walkSpeedEl) {
    walkSpeedEl.addEventListener("input", () => {
      const value = Number(walkSpeedEl.value);
      if (!Number.isFinite(value)) {
        walkSpeedEl.value = flySpeed.toFixed(1);
        return;
      }
      flySpeed = value;
      if (flyPresetSelect) flyPresetSelect.value = "custom";
    });
  }
  if (walkPitchEl) {
    walkPitchEl.addEventListener("input", () => {
      const value = Number(walkPitchEl.value);
      if (!Number.isFinite(value)) {
        const currentDeg = (flyPath && Number.isFinite(flyPath.pitch)) ? flyPath.pitch : viewer.camera.pitch * 180 / Math.PI;
        walkPitchEl.value = Number.isFinite(currentDeg) ? currentDeg.toFixed(1) : "-10.0";
        return;
      }
      if (flyPath) {
        flyPath.pitch = Math.max(-85, Math.min(0, value));
        if (flyPathCoords) {
          flyPathLinePositions = buildFlyPathLinePositions(flyPathCoords);
          updateFlyPathCamera(flyPathDistance);
        }
      } else if (walkModeActive) {
        const pitchRad = Math.max(-85 * Math.PI / 180, Math.min(-5 * Math.PI / 180, value * Math.PI / 180));
        viewer.camera.setView({
          destination: viewer.camera.position,
          orientation: { heading: viewer.camera.heading, pitch: pitchRad, roll: 0 }
        });
      }
      if (flyPresetSelect) flyPresetSelect.value = "custom";
    });
  }
  if (flyPresetSelect) {
    flyPresetSelect.addEventListener("change", () => {
      const presets = {
        walk: { height: 2, speed: 5, pitch: -5 },
        drive: { height: 2, speed: 60, pitch: -10 },
        drone: { height: 200, speed: 60, pitch: -30 },
        overview: { height: 1000, speed: 300, pitch: -45 }
      };
      const preset = presets[flyPresetSelect.value];
      if (!preset) return;
      flyHeight = preset.height;
      flySpeed = preset.speed;
      if (walkOffsetEl) walkOffsetEl.value = flyHeight.toFixed(1);
      if (walkSpeedEl) walkSpeedEl.value = flySpeed.toFixed(1);
      if (walkPitchEl) walkPitchEl.value = Number.isFinite(preset.pitch) ? preset.pitch.toFixed(1) : "-10.0";
      if (flyPath && Number.isFinite(preset.pitch)) {
        flyPath.pitch = Math.max(-85, Math.min(0, preset.pitch));
      }
      if (flyPathCoords && flyPath) {
        flyPathLinePositions = buildFlyPathLinePositions(flyPathCoords);
        updateFlyPathCamera(flyPathDistance);
      } else if (walkModeActive) {
        const pitchRad = Math.max(-85 * Math.PI / 180, Math.min(-5 * Math.PI / 180, preset.pitch * Math.PI / 180));
        viewer.camera.setView({
          destination: viewer.camera.position,
          orientation: { heading: viewer.camera.heading, pitch: pitchRad, roll: 0 }
        });
      }
    });
  }
  if (flyPointIndexEl) {
    flyPointIndexEl.addEventListener("change", () => {
      const index = Number(flyPointIndexEl.value);
      if (!flyPathCoords || !flyPathCoords[index]) return;
      flyPointOffsetEl.value = Number.isFinite(flyPathCoords[index].altitude) ? flyPathCoords[index].altitude.toFixed(1) : "0.0";
    });
  }
  if (flyPointOffsetEl) {
    flyPointOffsetEl.addEventListener("input", () => {
      const index = Number(flyPointIndexEl.value);
      const value = Number(flyPointOffsetEl.value);
      if (!flyPathCoords || !flyPathCoords[index] || !Number.isFinite(value)) return;
      flyPathCoords[index].altitude = value;
      if (flyPathCoords) flyPathLinePositions = buildFlyPathLinePositions(flyPathCoords);
    });
  }
  if (flyPointSaveEl) {
    flyPointSaveEl.addEventListener("click", saveFlyPointOffsets);
  }
  if (flyReverseBtn) {
    flyReverseBtn.addEventListener("click", () => {
      pauseFlyPath();
      if (flyPathCoords && flyPathCoords.length >= 2) {
        flyPathCoords.reverse();
        const total = flyPathCumulativeDistances[flyPathCumulativeDistances.length - 1] || 0;
        flyPathCumulativeDistances = flyPathCumulativeDistances.map((_, i, arr) => total - arr[arr.length - 1 - i]);
        flyPathLinePositions = buildFlyPathLinePositions(flyPathCoords);
        flyPathDistance = 0;
        updateFlyPathCamera(0);
        updateFlyPointEditor();
      } else if (walkModeActive) {
        const camera = viewer.camera;
        const heading = Cesium.Math.zeroToTwoPi(camera.heading + Math.PI);
        camera.setView({
          destination: camera.position,
          orientation: { heading, pitch: camera.pitch, roll: 0 }
        });
      }
    });
  }
  viewer.canvas.addEventListener("wheel", event => {
    if (!walkModeActive) return;
    event.preventDefault();
    flySpeed = flySpeed + Math.sign(event.deltaY) * 1;
    if (walkSpeedEl && document.activeElement !== walkSpeedEl) walkSpeedEl.value = flySpeed.toFixed(1);
  }, { passive: false });
  let walkLastTime = performance.now();
  let autoMove = 0;
  let walkRafId = null;
  const walkLoop = (timestamp) => {
    walkRafId = null;
    const delta = Math.min((timestamp - walkLastTime) / 1000, 0.1);
    walkLastTime = timestamp;
    if (walkModeActive) {
      const camera = viewer.camera;
      let heading = camera.heading;
      let pitch = camera.pitch;

      const turnDelta = 1.5 * delta;
      if (walkKeys.has("KeyA") || walkKeys.has("ArrowLeft")) heading -= turnDelta;
      if (walkKeys.has("KeyD") || walkKeys.has("ArrowRight")) heading += turnDelta;

      const pitchDelta = 0.8 * delta;
      if (walkKeys.has("ArrowUp")) pitch += pitchDelta;
      if (walkKeys.has("ArrowDown")) pitch -= pitchDelta;
      pitch = Math.max(-85 * Math.PI / 180, Math.min(-5 * Math.PI / 180, pitch));

      const manualMove = (walkKeys.has("KeyW") ? 1 : 0) - (walkKeys.has("KeyS") ? 1 : 0);
      const move = (manualMove !== 0) ? manualMove : autoMove;
      const speedChange = (walkKeys.has("Equal") || walkKeys.has("NumpadAdd") ? 1 : 0) -
        (walkKeys.has("Minus") || walkKeys.has("NumpadSubtract") ? 1 : 0);
      flySpeed += 100 * speedChange * delta;
      const moveDistance = (flySpeed / 3.6) * delta;
      if (move !== 0) {
        const normal = viewer.scene.globe.ellipsoid.geodeticSurfaceNormal(camera.position, new Cesium.Cartesian3());
        const dot = Cesium.Cartesian3.dot(camera.direction, normal);
        const horizontal = Cesium.Cartesian3.add(
          camera.direction,
          Cesium.Cartesian3.multiplyByScalar(normal, -dot, new Cesium.Cartesian3()),
          new Cesium.Cartesian3()
        );
        Cesium.Cartesian3.normalize(horizontal, horizontal);
        camera.move(horizontal, move * moveDistance);
      }

      const carto = Cesium.Cartographic.fromCartesian(camera.position);
      if (carto) {
        const terrainHeight = viewer.scene.globe.getHeight(carto) ?? 0;
        const heightChange = (walkKeys.has("KeyQ") ? 1 : 0) - (walkKeys.has("KeyE") ? 1 : 0);
        flyHeight += 10 * heightChange * delta;
        carto.height = terrainHeight + flyHeight;
        camera.setView({
          destination: Cesium.Cartesian3.fromRadians(carto.longitude, carto.latitude, carto.height),
          orientation: { heading, pitch, roll: 0 },
        });
        if (walkOffsetEl && document.activeElement !== walkOffsetEl) walkOffsetEl.value = flyHeight.toFixed(1);
        if (walkTerrainEl) walkTerrainEl.textContent = terrainHeight.toFixed(1);
        if (walkTerrainLabelEl) walkTerrainLabelEl.textContent = "地形高";
        if (walkSpeedEl && document.activeElement !== walkSpeedEl) walkSpeedEl.value = flySpeed.toFixed(1);
        if (walkPitchEl && document.activeElement !== walkPitchEl) walkPitchEl.value = (pitch * 180 / Math.PI).toFixed(1);
      }
      walkRafId = requestAnimationFrame(walkLoop);
    }
  };
  const walkHelp = document.querySelector("#walk-help");
  const ssec = viewer.scene.screenSpaceCameraController;
  const defaultLookEventTypes = ssec.lookEventTypes;
  const defaultZoomEventTypes = ssec.zoomEventTypes ? [...ssec.zoomEventTypes] : [];
  const wheelEventType = Cesium.CameraEventType?.WHEEL;
  let drawTabActive = false;
  const walkZoomWithoutWheel = wheelEventType
    ? defaultZoomEventTypes.filter(t => t !== wheelEventType)
    : defaultZoomEventTypes;
  const setMode = (next) => {
    const isWalk = next === "walk";
    const wasWalk = walkModeActive;
    modeSelect.value = next;
    modeSelect.textContent = isWalk ? "Fly" : "Orbit";
    modeSelect.setAttribute("aria-label", isWalk ? "Fly mode" : "Orbit view");
    walkModeActive = isWalk;
    autoMove = 0;
    walkHelp?.classList.toggle("visible", isWalk || drawTabActive);
    if (flyReverseBtn) flyReverseBtn.disabled = !isWalk;
    if (isWalk) {
      const carto = Cesium.Cartographic.fromCartesian(viewer.camera.position);
      if (carto) {
        const terrainHeight = viewer.scene.globe.getHeight(carto) ?? 0;
        flyHeight = carto.height - terrainHeight;
      }
    }
    ssec.enableZoom = true;
    ssec.lookEventTypes = defaultLookEventTypes;
    ssec.zoomEventTypes = isWalk && !drawTabActive
      ? walkZoomWithoutWheel
      : defaultZoomEventTypes;
    viewer.scene.mode = Cesium.SceneMode.SCENE3D;
    if (isWalk && !wasWalk) {
      const select = document.querySelector("#fly-path-select");
      const pathValue = select?.value || "__manual__";
      if (pathValue !== "__manual__" && !flyPathActive) {
        const index = Number(pathValue);
        if (Number.isFinite(index) && index >= 0 && index < flyPaths.length) void startFlyPath(index);
      } else if (pathValue === "__manual__" && !walkRafId) {
        stopFlyPath();
        walkLastTime = performance.now();
        walkRafId = requestAnimationFrame(walkLoop);
      }
    }
    if (!isWalk) {
      stopFlyPath();
      if (walkRafId) {
        cancelAnimationFrame(walkRafId);
        walkRafId = null;
      }
    }
  };
  modeSelect.addEventListener("click", () => {
    setMode(modeSelect.value === "orbit" ? "walk" : "orbit");
  });
  document.querySelector("#fly-path-select")?.addEventListener("change", () => {
    if (!walkModeActive) return;
    stopFlyPath();
    if (walkRafId) {
      cancelAnimationFrame(walkRafId);
      walkRafId = null;
    }
    const select = document.querySelector("#fly-path-select");
    const pathValue = select?.value || "__manual__";
    if (pathValue !== "__manual__") {
      const index = Number(pathValue);
      if (Number.isFinite(index) && index >= 0 && index < flyPaths.length) void startFlyPath(index);
    } else {
      walkLastTime = performance.now();
      walkRafId = requestAnimationFrame(walkLoop);
    }
  });

  const drawModeToggle = document.querySelector("#draw-mode-toggle");
  function updateDrawModeButton() { if (drawModeToggle) drawModeToggle.classList.toggle("active", drawModeActive); }
  function addDrawPoint(screenPosition) {
    if (!drawModeActive) return;
    const ray = viewer.camera.getPickRay(screenPosition);
    if (!ray) return;
    const cartesian = viewer.scene.globe.pick(ray, viewer.scene);
    if (!cartesian) return;
    const carto = Cesium.Cartographic.fromCartesian(cartesian);
    const point = Cesium.Cartesian3.fromRadians(carto.longitude, carto.latitude, carto.height + 20);
    if (drawnPoints.length > 0) {
      const last = drawnPoints[drawnPoints.length - 1];
      const dx = point.x - last.x;
      const dy = point.y - last.y;
      const dz = point.z - last.z;
      if (dx * dx + dy * dy + dz * dz < 25) return;
    }
    drawnPoints.push(point);
    if (!drawLineEntity) {
      drawLineEntity = viewer.entities.add({
        polyline: {
          positions: new Cesium.CallbackProperty(() => drawnPoints, false),
          width: 4,
          material: new Cesium.PolylineGlowMaterialProperty({ color: Cesium.Color.CYAN, glowPower: 0.15 }),
        },
      });
    }
  }
  function stopDrawMode() {
    drawModeActive = false;
    isDrawing = false;
    lastRightDownTime = 0;
    updateDrawModeButton();
    if (viewer.scene.screenSpaceCameraController) {
      ssec.zoomEventTypes = !walkModeActive || drawTabActive
        ? defaultZoomEventTypes
        : walkZoomWithoutWheel;
    }
  }
  function clearDrawnLine() {
    if (drawLineEntity) {
      viewer.entities.remove(drawLineEntity);
      drawLineEntity = null;
    }
    drawnPoints = [];
  }
  function buildDrawnGeoJson() {
    if (drawnPoints.length < 2) return null;
    const baseHeight = 20;
    const coordinates = drawnPoints.map(p => {
      const c = Cesium.Cartographic.fromCartesian(p);
      const lng = Number((c.longitude * 180 / Math.PI).toFixed(6));
      const lat = Number((c.latitude * 180 / Math.PI).toFixed(6));
      return [lng, lat, baseHeight];
    });
    return {
      type: "Feature",
      properties: { heightReference: "Terrain", heightOffset: baseHeight },
      geometry: { type: "LineString", coordinates },
    };
  }
  async function cacheDrawnLine() {
    if (!backendEnabled) return;
    const geojson = buildDrawnGeoJson();
    if (!geojson) return;
    const project = currentProjectId || "";
    const listUrl = `/api/files?project=${encodeURIComponent(project)}`;
    try {
      const listResponse = await fetch(listUrl);
      const files = listResponse.ok ? await listResponse.json() : [];
      const numbers = files
        .filter(name => /^drawn_route_(\d+)\.geojson$/.test(name))
        .map(name => Number(name.match(/^drawn_route_(\d+)\.geojson$/)[1]));
      const next = (numbers.length ? Math.max(...numbers) : 0) + 1;
      const path = `drawn_route_${next}.geojson`;
      const title = `描画ルート${next}`;
      const fileUrl = `/api/file?path=${encodeURIComponent(path)}&project=${encodeURIComponent(project)}`;
      const putResponse = await fetch(fileUrl, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(geojson) });
      if (!putResponse.ok) throw new Error(await putResponse.text());
      flyPaths.push({ title, url: fileUrl, speed: 30, height: 0, pitch: -10, loop: false, step: 100 });
      renderFlyPathSelect();
      const select = document.querySelector("#fly-path-select");
      const flyIndex = flyPaths.findIndex(p => p.url === fileUrl);
      if (select) select.value = String(flyIndex);
      const inspectorInput = document.querySelector("#inspector-input");
      if (inspectorInput) {
        const line = `fly_geojson: ${title} | ${fileUrl} | height=0`;
        if (!inspectorInput.value.includes(line)) {
          const text = inspectorInput.value;
          inspectorInput.value = text ? (text.trim().endsWith("\n") ? text + line + "\n" : text + "\n" + line + "\n") : line + "\n";
          void saveInspectorConfig().catch(error => console.warn("設定の保存に失敗しました:", error));
        }
      }
    } catch (error) {
      console.error("ルートのキャッシュに失敗しました:", error);
    }
  }

  function getCanvasPosition(event) {
    const rect = viewer.canvas.getBoundingClientRect();
    return new Cesium.Cartesian2(event.clientX - rect.left, event.clientY - rect.top);
  }
  const RIGHT_DOUBLE_MS = 400;
  let suppressContextMenu = false;
  function onDrawPointerDown(event) {
    if (!drawModeActive || event.button !== 2) return;
    event.preventDefault();
    const now = performance.now();
    const isDouble = now - lastRightDownTime < RIGHT_DOUBLE_MS;
    if (isDouble) {
      lastRightDownTime = 0;
      suppressContextMenu = true;
      if (drawnPoints.length >= 2) {
        void cacheDrawnLine();
        stopDrawMode();
      }
      return;
    }
    lastRightDownTime = now;
    addDrawPoint(getCanvasPosition(event));
  }
  function onDrawContextMenu(event) {
    if (!drawModeActive && !suppressContextMenu) return;
    event.preventDefault();
    suppressContextMenu = false;
  }

  viewer.canvas.addEventListener("pointerdown", onDrawPointerDown, { passive: false });
  viewer.canvas.addEventListener("contextmenu", onDrawContextMenu, { passive: false });

  if (drawModeToggle) {
    drawModeToggle.addEventListener("click", () => {
      if (drawModeActive) {
        stopDrawMode();
      } else {
        if (walkModeActive || flyPathActive) setMode("orbit");
        clearDrawnLine();
        drawModeActive = true;
        updateDrawModeButton();
        if (viewer.scene.screenSpaceCameraController) {
          const ssec = viewer.scene.screenSpaceCameraController;
          ssec.enableZoom = true;
          const rightDrag = Cesium.CameraEventType.RIGHT_DRAG;
          ssec.zoomEventTypes = defaultZoomEventTypes.filter(t => t !== rightDrag && t?.eventType !== rightDrag);
        }
      }
    });
  }
  const openDrawnRoute = document.querySelector("#open-drawn-route");
  if (openDrawnRoute) {
    openDrawnRoute.addEventListener("click", () => {
      if (!backendEnabled) return;
      const project = currentProjectId || "";
      const openUrl = `/api/open?path=drawn_route.geojson&project=${encodeURIComponent(project)}`;
      void fetch(openUrl, { method: "POST" }).catch(error => console.error("フォルダを開けませんでした:", error));
    });
  }

  const lastKeyTap = { KeyW: 0, KeyS: 0 };
  function startFlyPathLoopIfNeeded() {
    if (flyPathRafId === null && flyPathCoords && flyPathCoords.length) {
      flyPathActive = true;
      flyPathLastTime = performance.now();
      flyPathRafId = requestAnimationFrame(flyPathLoop);
    }
  }

  window.addEventListener("keydown", event => {
    if (!walkModeActive) return;
    if (["INPUT", "SELECT", "TEXTAREA"].includes(event.target?.tagName)) return;
    const code = event.code;
    if (["KeyW", "KeyS", "KeyA", "KeyD", "KeyQ", "KeyE", "Equal", "Minus", "NumpadAdd", "NumpadSubtract", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Escape"].includes(code)) {
      event.preventDefault();
      if (code === "Escape") {
        setMode("orbit");
        return;
      }
      if (code === "KeyW" || code === "KeyS") {
        if (flyPath && flyPathCoords) {
          const direction = code === "KeyW" ? 1 : -1;
          const total = flyPathCumulativeDistances[flyPathCumulativeDistances.length - 1] || 0;
          flyPathTargetDistance = direction > 0 ? total : 0;
          startFlyPathLoopIfNeeded();
        } else if (!flyPathActive) {
          const now = performance.now();
          const direction = code === "KeyW" ? 1 : -1;
          if (!event.repeat && now - lastKeyTap[code] < 300) {
            autoMove = autoMove === direction ? 0 : direction;
          }
          if (!event.repeat) lastKeyTap[code] = now;
        }
      }
      walkKeys.add(code);
      if (!flyPathActive && flyPath && flyPathCoords && ["KeyQ", "KeyE", "Equal", "Minus", "NumpadAdd", "NumpadSubtract", "ArrowUp", "ArrowDown"].includes(code)) {
        applyWalkKeys(0.05);
        updateFlyPathCamera(flyPathDistance);
      }
    }
  });

  window.addEventListener("keyup", event => {
    walkKeys.delete(event.code);
  });

  document.querySelector("#layer-panel-toggle").addEventListener("click", event => {
    const panel = document.querySelector(".control-panel");
    const collapsed = panel.classList.toggle("collapsed");
    event.currentTarget.textContent = collapsed ? "+" : "−";
    event.currentTarget.setAttribute("aria-label", collapsed ? "展開" : "最小化");
  });

  document.querySelector("#basemap-toggle").addEventListener("click", event => {
    const control = document.querySelector(".basemap-control");
    const collapsed = control.classList.toggle("collapsed");
    event.currentTarget.textContent = collapsed ? "+" : "−";
    event.currentTarget.setAttribute("aria-label", collapsed ? "展開" : "最小化");
  });

  document.querySelector("#navigation-toggle").addEventListener("click", event => {
    const toolbar = document.querySelector(".navigation-toolbar");
    const collapsed = toolbar.classList.toggle("collapsed");
    event.currentTarget.textContent = collapsed ? "+" : "−";
    event.currentTarget.setAttribute("aria-label", collapsed ? "展開" : "最小化");
  });

  [".control-panel", ".basemap-control", ".navigation-toolbar"].forEach(selector => {
    const panel = document.querySelector(selector);
    if (!panel) return;
    ["click", "mousedown", "dblclick", "touchstart", "touchmove", "wheel"].forEach(type => {
      panel.addEventListener(type, event => event.stopPropagation());
    });
  });

  document.querySelector("#apply-inspector").addEventListener("click", async () => {
    try {
      setInspectorStatus("設定を保存しています。");
      await saveInspectorConfig();
      applyInspector(document.querySelector("#inspector-input").value);
      setInspectorStatus("設定を保存しました。");
    } catch (error) {
      setInspectorStatus(`設定を保存できません: ${error instanceof Error ? error.message : error}`, true);
    }
  });

  document.querySelector("#export-inspector")?.addEventListener("click", () => {
    const text = document.querySelector("#inspector-input").value;
    const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${currentProjectId || "kasugai_canvas"}.kasc`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    setInspectorStatus(".kasc ファイルをエクスポートしました。");
  });

  document.querySelector("#project-select")?.addEventListener("change", async event => {
    currentProjectId = event.target.value;
    const params = new URLSearchParams(window.location.search);
    if (currentProjectId) params.set("project", currentProjectId);
    else params.delete("project");
    window.history.replaceState(null, "", `${window.location.pathname}?${params.toString()}${window.location.hash}`);
    try {
      setInspectorStatus("プロジェクトを読み込んでいます。");
      await loadInspectorConfig();
    } catch (error) {
      setInspectorStatus(`プロジェクトを読み込めません: ${error instanceof Error ? error.message : error}`, true);
    }
  });

  document.querySelector("#copy-share-url").addEventListener("click", async () => {
    const c = Cesium.Cartographic.fromCartesian(viewer.camera.position);
    const lon = Number(c.longitude * 180 / Math.PI).toFixed(6);
    const lat = Number(c.latitude * 180 / Math.PI).toFixed(6);
    const pitch = Number(viewer.camera.pitch * 180 / Math.PI).toFixed(2);
    const heading = Number(viewer.camera.heading * 180 / Math.PI).toFixed(2);
    const height = Number(c.height).toFixed(1);
    const url = `${window.location.origin}${window.location.pathname}?longitude=${lon}&latitude=${lat}&height=${height}&pitch=${pitch}&heading=${heading}&project=${encodeURIComponent(currentProjectId)}`;
    document.querySelector("#share-url").value = url;
    await navigator.clipboard?.writeText(url);
  });

  document.querySelector("#shutdown-app").addEventListener("click", async () => {
    if (!backendEnabled) return;
    if (!confirm("KASUGAI Canvasを停止しますか？")) return;
    await fetch("/api/shutdown", { method: "POST" });
  });

  document.querySelector("#check-update").addEventListener("click", () => {
    void checkForUpdate();
  });

  document.querySelector("#install-update").addEventListener("click", () => {
    void installUpdate();
  });

  document.querySelector("#auto-update").addEventListener("change", () => {
    void saveUpdateSettings().catch(error => {
      document.querySelector("#version-status").textContent = `自動更新設定の保存エラー: ${error.message}`;
    });
  });

  document.querySelectorAll(".panel-tab").forEach(tab => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".panel-tab").forEach(item => item.classList.toggle("active", item === tab));
      document.querySelectorAll(".plugin-panel").forEach(panel => panel.classList.toggle("active", panel.id === tab.dataset.panel));
    });
  });

  document.querySelectorAll(".settings-tab").forEach(tab => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".settings-tab").forEach(item => item.classList.toggle("active", item === tab));
      document.querySelectorAll(".settings-subpanel").forEach(panel => panel.classList.toggle("active", panel.id === tab.dataset.settingsPanel));
    });
  });

  viewer.camera.changed.addEventListener(() => updateCameraInputs());


  const clickHandler = new Cesium.ScreenSpaceEventHandler(viewer.canvas);
  clickHandler.setInputAction(movement => {
    if (walkModeActive) return;
    const picked = viewer.scene.pick(movement.position);
    const attr = document.querySelector("#attr-content");
    attr.replaceChildren();
    document.querySelectorAll(".panel-tab").forEach(tab => tab.classList.toggle("active", tab.dataset.panel === "attr-panel"));
    document.querySelectorAll(".plugin-panel").forEach(panel => panel.classList.toggle("active", panel.id === "attr-panel"));

    if (!picked) {
      attr.textContent = "地物を選択すると属性を表示します。";
      return;
    }

    if (picked instanceof Cesium.Cesium3DTileFeature) {
      const table = document.createElement("table");
      table.style.width = "100%";
      table.style.borderCollapse = "collapse";
      table.style.fontSize = "12px";
      const names = picked.getPropertyNames ? picked.getPropertyNames() : [];
      names.forEach(name => {
        const tr = document.createElement("tr");
        const th = document.createElement("th");
        th.textContent = name;
        th.style.textAlign = "left";
        th.style.padding = "3px 6px";
        th.style.borderBottom = "1px solid #cbd9de";
        const td = document.createElement("td");
        const value = picked.getProperty(name);
        td.textContent = value === undefined ? "" : String(value);
        td.style.padding = "3px 6px";
        td.style.borderBottom = "1px solid #cbd9de";
        tr.append(th, td);
        table.append(tr);
      });
      attr.append(table);
      return;
    }

    if (Cesium.GeoJsonPrimitive && picked.parentPrimitive instanceof Cesium.GeoJsonPrimitive && picked.properties) {
      delete attr.dataset.layerId;
      delete attr.dataset.layerTitle;
      const table = document.createElement("table");
      table.style.width = "100%";
      table.style.borderCollapse = "collapse";
      table.style.fontSize = "12px";
      Object.entries(picked.properties).forEach(([key, value]) => {
        const tr = document.createElement("tr");
        const th = document.createElement("th");
        th.textContent = key;
        th.style.textAlign = "left";
        th.style.padding = "3px 6px";
        th.style.borderBottom = "1px solid #cbd9de";
        const td = document.createElement("td");
        td.textContent = value === undefined ? "" : String(value);
        td.style.padding = "3px 6px";
        td.style.borderBottom = "1px solid #cbd9de";
        tr.append(th, td);
        table.append(tr);
      });
      attr.append(table);
      return;
    }

    const entity = picked.id;
    if (entity?.properties) {
      const ds = entity.entityCollection && entity.entityCollection.owner;
      const match = ds ? vectorDataSources.find(item => item.ds === ds) : null;
      if (match) {
        attr.dataset.layerId = match.id;
        attr.dataset.layerTitle = match.title || match.id;
      } else {
        delete attr.dataset.layerId;
        delete attr.dataset.layerTitle;
      }
      const table = document.createElement("table");
      table.style.width = "100%";
      table.style.borderCollapse = "collapse";
      table.style.fontSize = "12px";
      const values = entity.properties.getValue(Cesium.JulianDate.now()) || {};
      Object.entries(values).forEach(([key, value]) => {
        const tr = document.createElement("tr");
        const th = document.createElement("th");
        th.textContent = key;
        th.style.textAlign = "left";
        th.style.padding = "3px 6px";
        th.style.borderBottom = "1px solid #cbd9de";
        const td = document.createElement("td");
        td.textContent = value === undefined ? "" : String(value);
        td.style.padding = "3px 6px";
        td.style.borderBottom = "1px solid #cbd9de";
        tr.append(th, td);
        table.append(tr);
      });
      attr.append(table);
      return;
    }

    attr.textContent = "選択した地物に属性情報がありません。";
  }, Cesium.ScreenSpaceEventType.LEFT_CLICK);

  let lastRightClick = 0;
  viewer.canvas.addEventListener("contextmenu", event => {
    event.preventDefault();
    if (!walkModeActive) return;
    const now = performance.now();
    if (now - lastRightClick < 400) {
      if (flyPath && flyPathCoords) toggleFlyPathDirection(-1);
      else autoMove = autoMove === -1 ? 0 : -1;
    }
    lastRightClick = now;
  });

  viewer.canvas.addEventListener("dblclick", event => {
    if (!walkModeActive) return;
    if (event.button === 0) {
      if (flyPath && flyPathCoords) toggleFlyPathDirection(1);
      else autoMove = autoMove === 1 ? 0 : 1;
    }
  });

  let middlePointerId = null;
  let lastMiddleRotateX = 0;
  const middleRotateSpeed = 0.005;
  viewer.canvas.addEventListener("pointerdown", event => {
    if (event.button !== 1 || walkModeActive) return;
    const pitchDeg = viewer.camera.pitch * 180 / Math.PI;
    if (pitchDeg > -85) return;
    middlePointerId = event.pointerId;
    lastMiddleRotateX = event.clientX;
    viewer.canvas.setPointerCapture(event.pointerId);
    event.preventDefault();
    event.stopPropagation();
  }, { passive: false, capture: true });
  viewer.canvas.addEventListener("pointermove", event => {
    if (middlePointerId === null || event.pointerId !== middlePointerId) return;
    if ((event.buttons & 4) === 0) { middlePointerId = null; return; }
    const deltaX = event.clientX - lastMiddleRotateX;
    if (deltaX === 0) return;
    lastMiddleRotateX = event.clientX;
    const newHeading = viewer.camera.heading + deltaX * middleRotateSpeed;
    viewer.camera.setView({
      destination: viewer.camera.position,
      orientation: { heading: newHeading, pitch: -Math.PI / 2, roll: 0 },
    });
    event.preventDefault();
    event.stopPropagation();
  }, { passive: false, capture: true });
  viewer.canvas.addEventListener("pointerup", event => {
    if (middlePointerId === null || event.pointerId !== middlePointerId) return;
    middlePointerId = null;
    event.preventDefault();
    event.stopPropagation();
  }, { passive: false, capture: true });
  viewer.canvas.addEventListener("pointercancel", event => {
    if (middlePointerId === null || event.pointerId !== middlePointerId) return;
    middlePointerId = null;
  }, { passive: false, capture: true });

  const walkHelpToggle = document.querySelector("#walk-help-toggle");
  if (walkHelpToggle) {
    walkHelpToggle.addEventListener("click", () => {
      const minimized = walkHelp.classList.toggle("minimized");
      walkHelpToggle.textContent = minimized ? "+" : "−";
      walkHelpToggle.setAttribute("aria-label", minimized ? "展開" : "最小化");
    });
  }

  document.querySelectorAll(".walk-help-tab").forEach(tab => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".walk-help-tab").forEach(t => t.classList.remove("active"));
      document.querySelectorAll(".walk-help-content").forEach(c => c.classList.remove("active"));
      tab.classList.add("active");
      document.querySelector(`.walk-help-content[data-tab="${tab.dataset.tab}"]`)?.classList.add("active");
      const nextDrawTab = tab.dataset.tab === "draw";
      if (drawModeActive && !nextDrawTab) stopDrawMode();
      drawTabActive = nextDrawTab;
      setMode(drawTabActive ? "orbit" : "walk");
    });
  });
  setupVectorSearch();
}

function setupVectorSearch() {
  const vectorLayer = document.querySelector("#vector-layer");
  const vectorAttr = document.querySelector("#vector-attr");
  const vectorValue = document.querySelector("#vector-value");
  const vectorFlyBtn = document.querySelector("#vector-fly-btn");
  const vectorRefreshBtn = document.querySelector("#vector-refresh-btn");
  const vectorSearchText = document.querySelector("#vector-search-text");
  const vectorTextSearchBtn = document.querySelector("#vector-text-search-btn");
  const vectorSearchResults = document.querySelector("#vector-search-results");

  function performVectorTextSearch() {
    try {
      if (!vectorSearchResults || !vectorSearchData) return;
      const q = vectorSearchText ? String(vectorSearchText.value).trim() : "";
      if (!q) { vectorSearchResults.innerHTML = ""; return; }
      const query = q.toLowerCase();
      const targetLayerId = (vectorLayer && vectorLayer.value) ? vectorLayer.value : "__all__";
      const targetAttr = (vectorAttr && vectorAttr.value) ? vectorAttr.value : "__all__";
      const data = vectorSearchData;
      const res = [];
      const layerIds = (targetLayerId === "__all__") ? ["__all__"] : [targetLayerId];
      for (const layerId of layerIds) {
        try {
          const source = (layerId === "__all__") ? data.all : (data.layers && data.layers[layerId]);
          if (!source) continue;
          const attrList = (targetAttr === "__all__") ? (source.attributes || []) : [targetAttr];
          for (const attr of attrList) {
            if (!attr || attr === "__all__") continue;
            const values = (source.valuesByAttr && Array.isArray(source.valuesByAttr[attr])) ? source.valuesByAttr[attr] : [];
            for (const val of values) {
              const haystack = (String(val) + " " + String(attr)).toLowerCase();
              if (haystack.includes(query)) {
                const layerTitle = (layerId === "__all__") ? "全選択" : ((data.layers && data.layers[layerId] && data.layers[layerId].title) || layerId);
                const pos = (source.featureByAttr && source.featureByAttr[attr] && source.featureByAttr[attr][val]) || null;
                res.push({ layerId: (layerId === "__all__") ? "__all__" : layerId, layerTitle, attr, value: val, lat: pos ? pos.lat : null, lng: pos ? pos.lng : null });
              }
            }
          }
        } catch (e) {}
      }
      if (!res.length) {
        vectorSearchResults.innerHTML = '<li style="padding:4px;color:#71818d;">該当なし</li>';
        return;
      }
      vectorSearchResults.innerHTML = res.slice(0, 50).map((r, i) =>
        '<li class="vector-search-result" data-idx="' + i + '" style="padding:4px;border-bottom:1px solid #e4ecef;cursor:pointer;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' +
        escapeHtml(r.layerTitle) + ' / ' + escapeHtml(r.attr) + ' / ' + escapeHtml(r.value) +
        '</li>'
      ).join("");
      vectorSearchResults._resultData = res;
    } catch (e) { console.error("vector text search error", e); }
  }

  if (vectorSearchResults) {
    vectorSearchResults.addEventListener("click", (ev) => {
      try {
        const li = ev.target.closest && ev.target.closest("li[data-idx]");
        if (!li || !vectorSearchResults._resultData) return;
        const r = vectorSearchResults._resultData[Number(li.getAttribute("data-idx"))];
        if (!r) return;
        if (Number.isFinite(r.lat) && Number.isFinite(r.lng)) {
          flyToFeature(r.lat, r.lng);
        }
      } catch (e) { console.error("vector result click error", e); }
    });
  }

  if (vectorTextSearchBtn) vectorTextSearchBtn.addEventListener("click", performVectorTextSearch);
  if (vectorSearchText) vectorSearchText.addEventListener("keydown", (ev) => { if (ev.key === "Enter") performVectorTextSearch(); });

  if (vectorLayer) {
    vectorLayer.addEventListener("change", () => {
      try {
        const source = getCurrentVectorSource();
        if (vectorAttr) {
          if (source && source.attributes && source.attributes.length) {
            vectorAttr.innerHTML = '<option value="__all__">全選択</option>' + source.attributes.map(a => '<option value="' + escapeHtml(a) + '">' + escapeHtml(a) + '</option>').join("");
            vectorAttr.disabled = false;
          } else {
            vectorAttr.innerHTML = '<option value="__all__">全選択</option>';
            vectorAttr.disabled = true;
          }
          vectorAttr.value = "__all__";
        }
        if (vectorValue) {
          vectorValue.innerHTML = '<option value="">値を選択</option>';
          vectorValue.disabled = true;
        }
        if (vectorFlyBtn) vectorFlyBtn.disabled = true;
        if (vectorAttrWidget && vectorAttrWidget.classList.contains("visible")) {
          buildVectorAttrWidgetRows();
          renderVectorAttrWidget(vectorAttrWidgetSearch ? vectorAttrWidgetSearch.value : "");
        }
      } catch (e) { console.error("vector layer change error", e); }
    });
  }

  if (vectorAttr) {
    vectorAttr.addEventListener("change", () => {
      try {
        const source = getCurrentVectorSource();
        const attr = vectorAttr.value;
        if (vectorValue) {
          if (source && source.valuesByAttr && attr && attr !== "__all__" && Array.isArray(source.valuesByAttr[attr])) {
            vectorValue.innerHTML = '<option value="">値を選択</option>' + source.valuesByAttr[attr].map(v => '<option value="' + escapeHtml(v) + '">' + escapeHtml(v) + '</option>').join("");
            vectorValue.disabled = false;
          } else {
            vectorValue.innerHTML = '<option value="">値を選択</option>';
            vectorValue.disabled = true;
          }
          vectorValue.value = "";
          if (vectorFlyBtn) vectorFlyBtn.disabled = true;
        }
      } catch (e) { console.error("vector attr change error", e); }
    });
  }

  if (vectorValue) {
    vectorValue.addEventListener("change", () => {
      if (vectorFlyBtn) vectorFlyBtn.disabled = !vectorValue.value;
    });
  }

  if (vectorFlyBtn) {
    vectorFlyBtn.addEventListener("click", () => {
      try {
        if (!vectorLayer || !vectorAttr || !vectorValue || !vectorAttr.value || !vectorValue.value) return;
        const source = getCurrentVectorSource();
        const pos = (source && source.featureByAttr && source.featureByAttr[vectorAttr.value] && source.featureByAttr[vectorAttr.value][vectorValue.value]) || null;
        if (pos && Number.isFinite(pos.lat) && Number.isFinite(pos.lng)) {
          flyToFeature(pos.lat, pos.lng);
        }
      } catch (e) { console.error("vector fly error", e); }
    });
  }

  if (vectorRefreshBtn) {
    vectorRefreshBtn.addEventListener("click", () => {
      try {
        const status = document.querySelector("#vector-search-status");
        if (status) status.textContent = "読み込み中...";
        buildVectorSearchIndex();
        updateVectorSearchUI();
      } catch (e) { console.error("vector refresh error", e); }
    });
  }

  const vectorAttrListBtn = document.querySelector("#vector-attr-list-btn");
  const vectorAttrWidget = document.querySelector("#vector-attr-widget");
  const vectorAttrWidgetClose = document.querySelector(".vector-attr-widget-close");
  const vectorAttrWidgetResizer = document.querySelector(".vector-attr-widget-resizer");
  const vectorAttrWidgetSearch = document.querySelector("#vector-attr-widget-search");
  const vectorAttrWidgetLayerSelect = document.querySelector("#vector-attr-widget-layer");
  const vectorAttrWidgetHead = document.querySelector("#vector-attr-widget-head");
  const vectorAttrWidgetList = document.querySelector("#vector-attr-widget-list");
  const vectorAttrWidgetCount = document.querySelector("#vector-attr-widget-count");
  const vectorAttrWidgetTitle = document.querySelector(".vector-attr-widget-title");
  let vectorAttrWidgetRows = [];
  let vectorAttrWidgetAttributes = [];
  let vectorAttrWidgetSort = { column: -1, order: 1 };

  function getVectorDataSourceById(layerId) {
    if (layerId === "__all__") return null;
    return vectorDataSources.find(item => item.id === layerId) || null;
  }

  function buildVectorAttrWidgetRows() {
    vectorAttrWidgetRows = [];
    vectorAttrWidgetAttributes = [];
    vectorAttrWidgetSort = { column: -1, order: 1 };
    const layerId = (vectorLayer && vectorLayer.value) ? vectorLayer.value : "__all__";
    const dsItem = getVectorDataSourceById(layerId);
    const source = getCurrentVectorSource();
    if (!dsItem || !source || !source.attributes || !source.attributes.length) return;
    const time = viewer.clock && viewer.clock.currentTime;
    vectorAttrWidgetAttributes = source.attributes.slice();
    const maxRows = 1000;
    let count = 0;
    for (const entity of dsItem.ds.entities.values) {
      if (count++ >= maxRows) break;
      const props = (entity.properties && entity.properties.getValue) ? entity.properties.getValue(time) : (entity.properties || {});
      const row = [];
      for (const attr of vectorAttrWidgetAttributes) {
        const raw = props ? props[attr] : undefined;
        const val = (raw == null) ? "" : (typeof raw === "object" ? JSON.stringify(raw) : String(raw));
        row.push(val);
      }
      const cartesian = getEntityPosition(entity);
      const deg = cartesian ? cartesianToDegrees(cartesian) : null;
      vectorAttrWidgetRows.push({
        values: row,
        lat: deg && Number.isFinite(deg.lat) ? deg.lat : null,
        lng: deg && Number.isFinite(deg.lng) ? deg.lng : null,
      });
    }
  }

  function renderVectorAttrWidget(filter = "") {
    try {
      if (!vectorAttrWidgetList || !vectorAttrWidgetCount || !vectorAttrWidgetTitle) return;
      const query = String(filter).toLowerCase().trim();
      let matched = query ? vectorAttrWidgetRows.filter(row => row.values.some(val => String(val).toLowerCase().includes(query))) : [...vectorAttrWidgetRows];
      if (vectorAttrWidgetSort.column >= 0 && vectorAttrWidgetSort.column < vectorAttrWidgetAttributes.length) {
        const col = vectorAttrWidgetSort.column;
        const order = vectorAttrWidgetSort.order;
        matched.sort((a, b) => {
          const left = a.values[col] || "";
          const right = b.values[col] || "";
          const cmp = String(left).localeCompare(String(right), undefined, { numeric: true, sensitivity: "base" });
          return cmp * order;
        });
      }
      const displayRows = matched.slice(0, 1000);
      const layerTitle = (vectorLayer && vectorLayer.value !== "__all__" && vectorSearchData && vectorSearchData.layers && vectorSearchData.layers[vectorLayer.value] && vectorSearchData.layers[vectorLayer.value].title) ? vectorSearchData.layers[vectorLayer.value].title : "全選択";
      vectorAttrWidgetTitle.textContent = "属性・値一覧" + (layerTitle ? " — " + layerTitle : "");
      if (!vectorAttrWidgetAttributes.length) {
        if (vectorAttrWidgetHead) vectorAttrWidgetHead.innerHTML = "";
        vectorAttrWidgetList.innerHTML = '<tr><td style="padding:12px 14px;color:#71818d;">レイヤを選択してください</td></tr>';
        vectorAttrWidgetCount.textContent = "0 件 / 0 属性";
        return;
      }
      if (vectorAttrWidgetHead) {
        vectorAttrWidgetHead.innerHTML = '<tr>' + vectorAttrWidgetAttributes.map((attr, idx) => {
          const active = vectorAttrWidgetSort.column === idx;
          const marker = active ? (vectorAttrWidgetSort.order > 0 ? ' ▲' : ' ▼') : '';
          return '<th data-idx="' + idx + '" title="クリックで並び替え"' + (active ? ' class="sorted"' : '') + '>' + escapeHtml(attr) + '<span class="sort-marker">' + marker + '</span></th>';
        }).join("") + '</tr>';
      }
      if (!displayRows.length) {
        vectorAttrWidgetList.innerHTML = '<tr><td colspan="' + vectorAttrWidgetAttributes.length + '" style="padding:12px 14px;color:#71818d;">該当する地物がありません</td></tr>';
        vectorAttrWidgetCount.textContent = (query ? "0" : String(vectorAttrWidgetRows.length)) + " 件 / " + vectorAttrWidgetAttributes.length + " 属性";
        return;
      }
      vectorAttrWidgetList.innerHTML = displayRows.map(row => {
        const flyable = Number.isFinite(row.lat) && Number.isFinite(row.lng);
        const dataAttrs = flyable ? 'data-lat="' + row.lat + '" data-lng="' + row.lng + '"' : '';
        const style = flyable ? 'style="cursor:pointer;"' : '';
        return '<tr class="vector-attr-widget-row" ' + dataAttrs + ' ' + style + ' title="' + (flyable ? 'クリックで移動' : '') + '">' +
          row.values.map(val => '<td class="vector-attr-widget-cell" title="' + escapeHtml(val) + '">' + escapeHtml(val) + '</td>').join("") +
          '</tr>';
      }).join("");
      const suffix = (matched.length > displayRows.length) ? " （表示上限 " + displayRows.length + " 件）" : "";
      vectorAttrWidgetCount.textContent = String(matched.length) + " 件 / " + vectorAttrWidgetAttributes.length + " 属性" + suffix;
    } catch (e) { console.error("vector attr widget render error", e); }
  }

  function updateVectorAttrWidgetLayerOptions(layerId) {
    if (!vectorAttrWidgetLayerSelect) return;
    const opts = (vectorSearchData && vectorSearchData.layerOptions) || [];
    let html = '<option value="">レイヤを選択</option>';
    for (const o of opts) {
      html += '<option value="' + escapeHtml(o.id) + '">' + escapeHtml(o.title || o.id) + '</option>';
    }
    vectorAttrWidgetLayerSelect.innerHTML = html;
    const hasLayer = layerId && layerId !== "__all__" && opts.some(o => o.id === layerId);
    vectorAttrWidgetLayerSelect.value = hasLayer ? layerId : "";
  }

  function openVectorAttrWidget(layerId = null) {
    if (!vectorAttrWidget) return;
    if (vectorLayer) {
      if (layerId && layerId !== "__all__" && [...vectorLayer.options].some(option => option.value === layerId)) {
        vectorLayer.value = layerId;
      } else if (!layerId || layerId === "__all__") {
        vectorLayer.value = "__all__";
      }
    }
    updateVectorAttrWidgetLayerOptions(layerId || (vectorLayer ? vectorLayer.value : null));
    buildVectorAttrWidgetRows();
    renderVectorAttrWidget(vectorAttrWidgetSearch ? vectorAttrWidgetSearch.value : "");
    vectorAttrWidget.classList.add("visible");
    if (vectorAttrWidgetSearch) vectorAttrWidgetSearch.focus();
  }

  function closeVectorAttrWidget() {
    if (vectorAttrWidget) vectorAttrWidget.classList.remove("visible");
  }

  if (vectorAttrListBtn) vectorAttrListBtn.addEventListener("click", () => openVectorAttrWidget(vectorLayer ? vectorLayer.value : null));
  const attrVectorAttrListBtn = document.querySelector("#attr-vector-attr-list-btn");
  const attrContent = document.querySelector("#attr-content");
  if (attrVectorAttrListBtn) {
    attrVectorAttrListBtn.addEventListener("click", () => {
      const layerId = (attrContent && attrContent.dataset.layerId) ? attrContent.dataset.layerId : (vectorLayer ? vectorLayer.value : null);
      openVectorAttrWidget(layerId);
    });
  }
  if (vectorAttrWidgetClose) vectorAttrWidgetClose.addEventListener("click", closeVectorAttrWidget);
  if (vectorAttrWidgetSearch) {
    vectorAttrWidgetSearch.addEventListener("input", () => renderVectorAttrWidget(vectorAttrWidgetSearch.value));
    vectorAttrWidgetSearch.addEventListener("keydown", (ev) => { if (ev.key === "Enter") renderVectorAttrWidget(vectorAttrWidgetSearch.value); });
  }

  if (vectorAttrWidgetLayerSelect) {
    vectorAttrWidgetLayerSelect.addEventListener("change", () => {
      try { openVectorAttrWidget(vectorAttrWidgetLayerSelect.value); } catch (e) { console.error("vector attr layer change error", e); }
    });
  }

  if (vectorAttrWidgetList) {
    vectorAttrWidgetList.addEventListener("click", (ev) => {
      try {
        const tr = ev.target.closest("tr");
        if (!tr) return;
        const latAttr = tr.getAttribute("data-lat");
        const lngAttr = tr.getAttribute("data-lng");
        if (latAttr == null || lngAttr == null) return;
        const lat = Number(latAttr);
        const lng = Number(lngAttr);
        if (Number.isFinite(lat) && Number.isFinite(lng)) {
          flyToFeature(lat, lng);
        }
      } catch (e) { console.error("vector attr row click error", e); }
    });
  }

  if (vectorAttrWidgetHead) {
    vectorAttrWidgetHead.addEventListener("click", (ev) => {
      try {
        const th = ev.target.closest("th");
        if (!th || !th.hasAttribute("data-idx")) return;
        const idx = Number(th.getAttribute("data-idx"));
        if (vectorAttrWidgetSort.column === idx) {
          vectorAttrWidgetSort.order *= -1;
        } else {
          vectorAttrWidgetSort = { column: idx, order: 1 };
        }
        renderVectorAttrWidget(vectorAttrWidgetSearch ? vectorAttrWidgetSearch.value : "");
      } catch (e) { console.error("vector attr head click error", e); }
    });
  }

  if (vectorAttrWidgetResizer && vectorAttrWidget) {
    let startY = 0;
    let startHeight = 0;
    let isResizing = false;

    function onMouseMove(ev) {
      if (!isResizing) return;
      ev.preventDefault();
      const delta = startY - ev.clientY;
      const nextHeight = startHeight + delta;
      const maxHeight = Math.min(window.innerHeight * 0.9, 1200);
      const clamped = Math.max(120, Math.min(maxHeight, nextHeight));
      vectorAttrWidget.style.height = clamped + "px";
    }

    function onMouseUp() {
      isResizing = false;
      document.body.style.cursor = "";
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup", onMouseUp);
      if (window.getSelection) window.getSelection().removeAllRanges();
    }

    vectorAttrWidgetResizer.addEventListener("mousedown", (ev) => {
      ev.preventDefault();
      isResizing = true;
      startY = ev.clientY;
      startHeight = vectorAttrWidget.offsetHeight;
      document.body.style.cursor = "ns-resize";
      window.addEventListener("mousemove", onMouseMove);
      window.addEventListener("mouseup", onMouseUp);
    });
  }

  window.vectorAttrWidget = { open: openVectorAttrWidget, close: closeVectorAttrWidget };
}

function compareVersions(left, right) {
  const a = left.split(".").map(Number);
  const b = right.split(".").map(Number);
  for (let index = 0; index < Math.max(a.length, b.length); index += 1) {
    const leftPart = Number.isFinite(a[index]) ? a[index] : 0;
    const rightPart = Number.isFinite(b[index]) ? b[index] : 0;
    if (leftPart !== rightPart) return leftPart > rightPart ? 1 : -1;
  }
  return 0;
}

async function loadUpdateInfo() {
  const current = document.querySelector("#current-version");
  if (!backendEnabled) {
    if (current) current.textContent = "-";
    return;
  }
  try {
    const [healthResponse, settingsResponse] = await Promise.all([
      fetch("/health"),
      fetch("/api/update/settings"),
    ]);
    if (!healthResponse.ok || !settingsResponse.ok) throw new Error("更新情報を取得できませんでした");
    const health = await healthResponse.json();
    const settings = await settingsResponse.json();
    current.textContent = health.version || "-";
    if (Number.isInteger(health.port)) document.querySelector("#current-port").value = health.port;
    document.querySelector("#auto-update").checked = settings.autoUpdate !== false;
    await checkForUpdate(health.version);
  } catch (error) {
    current.textContent = "-";
    document.querySelector("#version-status").textContent = `更新情報を取得できません: ${error.message}`;
  }
}

async function checkForUpdate(currentVersion = document.querySelector("#current-version").textContent) {
  const status = document.querySelector("#version-status");
  const updateStatus = document.querySelector("#update-status");
  const installButton = document.querySelector("#install-update");
  status.textContent = "最新バージョンを確認中...";
  installButton.hidden = true;
  try {
    const response = await fetch("/api/update/latest");
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    const latestVersion = data.version || "-";
    document.querySelector("#latest-version").textContent = latestVersion;
    const comparison = compareVersions(currentVersion, latestVersion);
    if (comparison < 0) {
      updateStatus.textContent = "（新しいバージョンがあります）";
      status.textContent = "更新が利用可能です";
      installButton.hidden = false;
      if (document.querySelector("#auto-update").checked) await installUpdate(latestVersion, true);
    } else if (comparison === 0) {
      updateStatus.textContent = "（最新です）";
      status.textContent = "";
    } else {
      updateStatus.textContent = "（現在のバージョンの方が新しいです）";
      status.textContent = "";
    }
  } catch (error) {
    document.querySelector("#latest-version").textContent = "-";
    status.textContent = `更新確認エラー: ${error.message}`;
  }
}

async function installUpdate(latestVersion = document.querySelector("#latest-version").textContent, silent = false) {
  if (!silent && !confirm(`新しいバージョン ${latestVersion} が利用可能です。ダウンロードしてインストールしますか？`)) {
    document.querySelector("#version-status").textContent = "アップデートをキャンセルしました";
    return;
  }
  const button = document.querySelector("#install-update");
  button.disabled = true;
  document.querySelector("#version-status").textContent = "最新版をダウンロードして自動インストールを準備中...";
  try {
    const response = await fetch("/api/update/install", { method: "POST" });
    const body = await response.text();
    let data;
    try {
      data = body ? JSON.parse(body) : {};
    } catch {
      data = {};
    }
    if (!response.ok) throw new Error(data.error || body || `HTTP ${response.status}`);
    document.querySelector("#version-status").textContent = data.message || "アップデートを開始しました";
    void reloadAfterRestart();
  } catch (error) {
    document.querySelector("#version-status").textContent = `自動インストールエラー: ${error.message}`;
    button.disabled = false;
  }
}

async function reloadAfterRestart() {
  const status = document.querySelector("#version-status");
  const ping = async () => {
    try {
      const response = await fetch("/health", { cache: "no-store" });
      return response.ok;
    } catch {
      return false;
    }
  };
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  status.textContent = "更新中... サーバーの再起動を待っています";
  // 旧サーバーの停止を待つ（早すぎるリロードを防ぐ）
  for (let i = 0; i < 60 && await ping(); i++) await sleep(1000);
  // 新サーバーの起動を待ってリロード（カメラ位置はURLハッシュから復元される）
  for (let i = 0; i < 120; i++) {
    await sleep(1000);
    if (await ping()) {
      window.location.reload();
      return;
    }
  }
  status.textContent = "再起動を確認できませんでした。手動でページを再読み込みしてください。";
}

async function saveUpdateSettings() {
  if (!backendEnabled) return;
  const autoUpdate = document.querySelector("#auto-update").checked;
  const response = await fetch("/api/update/settings", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ autoUpdate }),
  });
  if (!response.ok) throw new Error(await response.text());
  document.querySelector("#version-status").textContent = "自動更新設定を保存しました";
}

const defaultConfig = `base: 地理院タイル 標準地図 | https://cyberjapandata.gsi.go.jp/xyz/std/{z}/{x}/{y}.png | 出典：国土地理院
3dtiles: 東京都/千代田区（建築物LOD1） | https://assets.cms.plateau.reearth.io/assets/0e/e5948a-e95c-4e31-be85-1f8c066ed996/13101_chiyoda-ku_pref_2023_citygml_1_op_bldg_3dtiles_13101_chiyoda-ku_lod1/tileset.json
cam:東京駅|35.653108|139.761449|height=2200.6|pitch=-30|heading=348.5`;

document.querySelector("#current-port").value = window.location.port || (window.location.protocol === "https:" ? "443" : "8510");
setupEvents();

viewer.camera.moveEnd.addEventListener(() => {
  const ssec = viewer.scene.screenSpaceCameraController;
  if (!ssec.enableTilt) return;
  const pitchDeg = viewer.camera.pitch * 180 / Math.PI;
  if (pitchDeg < -85) {
    viewer.camera.setView({
      destination: viewer.camera.position,
      orientation: { heading: viewer.camera.heading, pitch: -84.99 * Math.PI / 180, roll: 0 }
    });
  }
});

setupThreeJs();
applyInspector(defaultConfig);
updateEffectSettings();
const urlCamera = parseUrlCamera(initialCameraSource);

function parseUrlCamera(source = window.location.search + window.location.hash) {
  const hashIndex = source.indexOf("#");
  const searchPart = hashIndex >= 0 ? source.slice(0, hashIndex) : source;
  const hashPart = hashIndex >= 0 ? source.slice(hashIndex + 1) : "";
  const searchParams = new URLSearchParams(searchPart.startsWith("?") ? searchPart.slice(1) : searchPart);
  const hashParams = new URLSearchParams(hashPart);
  const getNumber = (name, fallback) => {
    const raw = hashParams.get(name) ?? searchParams.get(name);
    if (raw === null || raw === "") return fallback;
    const value = Number(raw);
    return Number.isFinite(value) ? value : fallback;
  };
  return {
    latitude: getNumber("latitude"),
    longitude: getNumber("longitude"),
    height: getNumber("height", DEFAULT_VIEW.height),
    pitch: getNumber("pitch", DEFAULT_VIEW.pitch),
    heading: getNumber("heading", DEFAULT_VIEW.heading),
  };
}

async function resolveInitialCamera() {
  if (Number.isFinite(urlCamera.latitude) && Number.isFinite(urlCamera.longitude)) {
    return urlCamera;
  }
  if (cameraPresets.length) {
    return cameraPresets[0];
  }
  try {
    const response = await fetch("https://ipapi.co/json/");
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    const latitude = Number(data.latitude);
    const longitude = Number(data.longitude);
    if (Number.isFinite(latitude) && Number.isFinite(longitude)) {
      return { latitude, longitude, height: 10000, pitch: DEFAULT_VIEW.pitch, heading: 0 };
    }
  } catch (error) {
    console.warn("IP geolocation failed", error);
  }
  return DEFAULT_VIEW;
}

function applyUrlCamera() {
  const camera = parseUrlCamera();
  if (Number.isFinite(camera.latitude) && Number.isFinite(camera.longitude)) {
    flyTo(camera);
  }
}

window.addEventListener("popstate", applyUrlCamera);
window.addEventListener("hashchange", applyUrlCamera);

window.addEventListener("pagehide", () => {
  try {
    sessionStorage.setItem("lastCameraSearch", window.location.search + window.location.hash);
  } catch (e) {}
});

(async () => {
  await detectBackend();
  try { await loadProjects(); } catch (e) { console.error(e); }
  try { await loadInspectorConfig(); } catch (e) { console.error(e); }
  try { await loadUpdateInfo(); } catch (e) { console.error(e); }
  const initialCamera = await resolveInitialCamera();
  // 前回のカメラ位置は起動直後に即セット済み。URLの座標が変わっていればそこからFLYTOする
  if (hasLastCamera && lastCameraSearch !== initialCameraSource) {
    if (initialCamera) flyTo(initialCamera);      // 前回の位置から新しいURLへGoogle Earth風にFLYTO
  } else {
    if (initialCamera) flyTo(initialCamera, 0);   // 履歴がない or 同じURL
  }
  renderPresets();
})();
