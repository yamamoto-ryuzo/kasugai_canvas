// ミニマップ（ベースマップコントロールの #basemap-minimap アイコンボタンで切替。
// 状態は #display-minimap チェックボックス(hidden可)が保持し、ui-config defaults・setMinimap 経路も同じ）。
// 左下の小地図に現在の表示範囲矩形（または中心マーカー）を重ねる。
// Leaflet(UMD)は module import でグローバルに展開されないため script タグで遅延ロードする。
//
// createMinimap({
//   container : "#minimap" | HTMLElement   // ミニマップの配置先（無ければ document.body 直下に生成）
//   checkbox  : "#display-minimap" | HTMLElement | null   // 表示状態の保持先
//   button    : "#basemap-minimap" | HTMLElement | null   // クリックで切替。active クラス/aria-pressed を状態へ同期
//   tileUrl   : () => "{z}/{x}/{y}" テンプレート（省略時は地理院淡色地図）
//   getBounds : () => [[south,west],[north,east]] | null   // 表示範囲矩形
//   getCenter : () => {lat,lng} | null      // bounds が取れない場合のマーカー位置（省略可）
//   getZoom   : () => number | null         // フォールバック時の主画面相当ズーム（省略可）
//   flyTo     : ({lng,lat}) => void         // クリック地点への移動（省略可）
// }) → { scheduleUpdate(), update(), dispose() }
const LEAFLET_CDN = "https://cdn.jsdelivr.net/npm/leaflet@1.9.4";
const FALLBACK_TILE = "https://cyberjapandata.gsi.go.jp/xyz/pale/{z}/{x}/{y}.png";
// 主画面の表示範囲に対するミニマップ表示範囲の面積比（20倍 ≈ 線形4.5倍 ≈ 2.2ズーム引き）
const CONTEXT_AREA_RATIO = 20;
const CONTEXT_ZOOM_DELTA = Math.log2(Math.sqrt(CONTEXT_AREA_RATIO));

const CSS = `
.kasc-minimap { position: absolute; left: 14px; bottom: 74px; z-index: 1004; width: 220px; height: 150px;
  border: 1px solid rgba(14,32,64,.25); border-radius: 6px; overflow: hidden;
  box-shadow: 0 4px 12px rgba(10,20,40,.2); }
.kasc-minimap .leaflet-container { width: 100%; height: 100%; background: #dfe6ea; cursor: crosshair; }
`;

let styleInjected = false;
function ensureStyle() {
  if (styleInjected || document.querySelector("#kasc-minimap-style")) return;
  styleInjected = true;
  const el = document.createElement("style");
  el.id = "kasc-minimap-style";
  el.textContent = CSS;
  document.head.append(el);
}

let leafletPromise = null;
function loadLeaflet() {
  if (window.L) return Promise.resolve(window.L);
  if (!leafletPromise) {
    if (!document.querySelector('link[href*="leaflet.css"]')) {
      const link = document.createElement("link");
      link.rel = "stylesheet";
      link.href = `${LEAFLET_CDN}/dist/leaflet.css`;
      document.head.append(link);
    }
    leafletPromise = new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = `${LEAFLET_CDN}/dist/leaflet.js`;
      s.onload = () => window.L ? resolve(window.L) : reject(new Error("leaflet load failed"));
      s.onerror = () => reject(new Error("leaflet load failed"));
      document.head.append(s);
    });
    leafletPromise.catch(() => { leafletPromise = null; });
  }
  return leafletPromise;
}

export function createMinimap({ container, checkbox, button, tileUrl, getBounds, getCenter, getZoom, flyTo } = {}) {
  ensureStyle();
  const el = typeof container === "string" ? document.querySelector(container) : (container || (() => {
    const d = document.createElement("div");
    d.id = "minimap";
    document.body.append(d);
    return d;
  })());
  const cb = typeof checkbox === "string" ? document.querySelector(checkbox) : checkbox;
  const btn = typeof button === "string" ? document.querySelector(button) : button;
  if (!el) return { scheduleUpdate() {}, update() {}, dispose() {} };
  el.classList.add("kasc-minimap");
  el.hidden = true;

  let state = null;   // { map, tile, rect, marker }
  let timer = null;
  let disposed = false;
  let manualOn = !cb;   // checkbox 無し環境では従来どおり初期 ON（ボタン操作で切替）
  const enabled = () => !disposed && (cb ? cb.checked : manualOn);
  const syncButton = () => {
    if (!btn) return;
    const on = enabled();
    btn.classList.toggle("active", on);
    btn.setAttribute("aria-pressed", on ? "true" : "false");
  };
  const wantTile = () => {
    const url = tileUrl && tileUrl();
    return /\{z\}.*\{x\}.*\{y\}|\{z\}.*\{y\}.*\{x\}/.test(url || "") ? url : FALLBACK_TILE;
  };

  async function update() {
    if (disposed) return;
    if (!enabled()) { el.hidden = true; return; }
    el.hidden = false;
    const L = await loadLeaflet().catch(() => null);
    if (!L || disposed || !enabled()) { if (!L) el.hidden = true; return; }
    if (!state) {
      const map = L.map(el, {
        zoomControl: false, attributionControl: false, dragging: false,
        scrollWheelZoom: false, doubleClickZoom: false, boxZoom: false,
        keyboard: false, touchZoom: false, zoomSnap: 0.25,
      });
      const tile = L.tileLayer(wantTile(), { opacity: 0.9 }).addTo(map);
      const rect = L.rectangle([[0, 0], [0, 0]], { color: "#e33d3d", weight: 1.5, fill: false, interactive: false });
      const marker = L.circleMarker([0, 0], { radius: 4, color: "#e33d3d", weight: 1.5, fillColor: "#e33d3d", fillOpacity: 1, interactive: false });
      if (flyTo) map.on("click", e => flyTo({ lng: e.latlng.lng, lat: e.latlng.lat }));
      state = { map, tile, rect, marker };
    } else {
      const want = wantTile();
      if (state.tile._url !== want) state.tile.setUrl(want);
      state.map.invalidateSize();
    }
    const b = getBounds && getBounds();
    if (b) {
      if (!state.rect._map) state.rect.addTo(state.map);
      if (state.marker._map) state.marker.remove();
      state.rect.setBounds(b);
      // 広域コンテキスト: 主画面範囲を CONTEXT_AREA_RATIO 倍(面積)に拡張して fit
      let [[s, w], [n, e]] = b;
      if (e < w) { w = -180; e = 180; }
      const k = (Math.sqrt(CONTEXT_AREA_RATIO) - 1) / 2;
      const dLat = Math.max(n - s, 1e-6) * k;
      const dLng = Math.max(e - w, 1e-6) * k;
      state.map.fitBounds(
        [[Math.max(-85.0511, s - dLat), Math.max(-180, w - dLng)],
         [Math.min(85.0511, n + dLat), Math.min(180, e + dLng)]],
        { animate: false, padding: [4, 4] });
    } else {
      if (state.rect._map) state.rect.remove();
      const c = getCenter && getCenter();
      if (c && Number.isFinite(c.lat) && Number.isFinite(c.lng)) {
        if (!state.marker._map) state.marker.addTo(state.map);
        state.marker.setLatLng([c.lat, c.lng]);
        const z = getZoom ? Math.max(2, getZoom() - CONTEXT_ZOOM_DELTA) : (state.map.getZoom() ?? 12);
        state.map.setView([c.lat, c.lng], z, { animate: false });
      }
    }
  }

  function scheduleUpdate() {
    if (!enabled()) return;
    clearTimeout(timer);
    timer = setTimeout(() => { void update(); }, 250);
  }

  cb?.addEventListener("change", () => { void update(); syncButton(); });
  btn?.addEventListener("click", () => {
    if (disposed) return;
    if (cb) {
      cb.checked = !cb.checked;
      cb.dispatchEvent(new Event("change"));
    } else {
      manualOn = !manualOn;
      syncButton();
      void update();
    }
  });
  syncButton();

  return {
    scheduleUpdate,
    update,
    dispose() {
      disposed = true;
      clearTimeout(timer);
      try { state?.map?.remove(); } catch (_) {}
      state = null;
      el.hidden = true;
    },
  };
}
