// ベクター系 .kasc 行 → GeoJSON FeatureCollection（エンジン非依存ローダー）
// 対象: geojson:/layer: / geoparquet:/parquet: / flatgeobuf:/fgb: / gpkg:/geopackage: /
//       csv:/tsv: / duckdb: / sql:
// duckdb:/sql: のクエリ実行は window.KascLoader(shared/kasc_loader.js) へ委譲する。
// bounds = {ranges:[{west,east}],south,north} は bbox=auto/:bbox 系の表示範囲として使う
import { wkbToGeoJsonGeometry, sanitizeVectorPropertyValue } from "./vector-decode.js";
import { resolveKascUrl } from "./kasc.js";

const FGB_URL = "https://cdn.jsdelivr.net/npm/flatgeobuf@4.6.1/lib/mjs/geojson.js/+esm";
const HYPARQUET_URL = "https://cdn.jsdelivr.net/npm/hyparquet@1.31.5/+esm";
const HYPARQUET_COMPRESSORS_URL = "https://cdn.jsdelivr.net/npm/hyparquet-compressors@1.1.2/+esm";
const TOGEOJSON_URL = "https://cdn.jsdelivr.net/npm/@tmcw/togeojson@7.1.3/+esm";
const JSZIP_URL = "https://cdn.jsdelivr.net/npm/jszip@3.10.1/+esm";
const SHP_URL = "https://cdn.jsdelivr.net/npm/shpjs@6.1.0/+esm";

let gpkgWorker = null;
let gpkgReqId = 0;
const gpkgPending = new Map();

function ensureGpkgWorker() {
  if (!gpkgWorker) {
    // import.meta.url 基準で解決する(plain "./gpkg-worker.js" はドキュメント
    // 基準のため /<engine>/gpkg-worker.js を指して 404 になる)
    gpkgWorker = new Worker(new URL("./gpkg-worker.js", import.meta.url), { type: "module" });
    gpkgWorker.onmessage = event => {
      const { reqId, error, ...result } = event.data || {};
      const entry = gpkgPending.get(reqId);
      if (!entry) return;
      gpkgPending.delete(reqId);
      if (error) entry.reject(new Error(error));
      else entry.resolve(result);
    };
    gpkgWorker.onerror = event => {
      for (const entry of gpkgPending.values()) entry.reject(new Error(String(event.message || event)));
      gpkgPending.clear();
      // 起動失敗 Worker を使い回すと以後の呼出が応答無しで固着するため破棄する
      try { gpkgWorker.terminate(); } catch (e) { /* ignore */ }
      gpkgWorker = null;
    };
  }
  return gpkgWorker;
}

function gpkgCommand(msg) {
  const reqId = ++gpkgReqId;
  return new Promise((resolve, reject) => {
    gpkgPending.set(reqId, { resolve, reject });
    ensureGpkgWorker().postMessage({ reqId, ...msg });
  });
}

function toFeatureCollection(items) {
  const features = [];
  for (const row of items) {
    if (!row) continue;
    let geom = row.geometry ?? row.geom;
    if (geom && !(geom.type)) {
      // WKB(Uint8Array) を GeoJSON ジオメトリへ
      if (geom instanceof Uint8Array || ArrayBuffer.isView(geom) || geom instanceof ArrayBuffer) {
        geom = wkbToGeoJsonGeometry(geom instanceof ArrayBuffer ? new Uint8Array(geom) : geom);
      } else if (typeof geom === "string" && /^[0-9a-fA-F]+$/.test(geom)) {
        const bytes = new Uint8Array(geom.length / 2);
        for (let i = 0; i < bytes.length; i++) bytes[i] = parseInt(geom.slice(i * 2, i * 2 + 2), 16);
        geom = wkbToGeoJsonGeometry(bytes);
      }
    }
    if (!geom || !geom.type) continue;
    const { geometry: _g, geom: _g2, ...rawProps } = row;
    // BigInt 等の structured-clone 不可な値は MapLibre GeoJSON ソースへ渡せないため変換
    const props = {};
    for (const [k, v] of Object.entries(rawProps)) {
      if (typeof v === "bigint") props[k] = v >= -9007199254740991n && v <= 9007199254740991n ? Number(v) : String(v);
      else props[k] = v;
    }
    features.push({ type: "Feature", geometry: geom, properties: props });
  }
  return { type: "FeatureCollection", features };
}

// 属性値の正規化(sanitize)は Cesium 版と共通。BigInt 等 structured-clone 不可な値も潰す
async function loadFlatGeobuf(url) {
  const { deserialize } = await import(FGB_URL);
  const res = await fetch(url);
  if (!res.ok || !res.body) throw new Error(`flatgeobuf 取得失敗: ${res.status}`);
  const fc = { type: "FeatureCollection", features: [] };
  for await (const feature of deserialize(res.body)) {
    if (!feature || !feature.geometry) continue;
    const properties = feature.properties;
    if (properties) {
      for (const key of Object.keys(properties)) {
        properties[key] = sanitizeVectorPropertyValue(properties[key]);
      }
    }
    fc.features.push(feature);
  }
  return fc;
}

let hyparquetLoaderPromise = null;
function loadHyparquet() {
  if (!hyparquetLoaderPromise) {
    hyparquetLoaderPromise = Promise.all([
      import(HYPARQUET_URL),
      import(HYPARQUET_COMPRESSORS_URL),
    ]).then(([hp, hc]) => ({
      parquetReadObjects: hp.parquetReadObjects,
      parquetMetadata: hp.parquetMetadataAsync || hp.parquetMetadata,
      asyncBufferFromUrl: hp.asyncBufferFromUrl,
      compressors: hc.compressors,
    }));
  }
  return hyparquetLoaderPromise;
}

// Cesium 版と同一実装: Range Request 対応の非同期バッファを優先し、
// geo メタデータの primary_column でジオメトリ列を特定する
async function loadGeoParquet(url) {
  const { parquetReadObjects, parquetMetadata, asyncBufferFromUrl, compressors } = await loadHyparquet();
  let file;
  try {
    file = await asyncBufferFromUrl({ url });
  } catch {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`geoparquet 取得失敗: ${res.status}`);
    file = await res.arrayBuffer();
  }
  const rows = await parquetReadObjects({ file, compressors });
  if (!rows.length) return { type: "FeatureCollection", features: [] };
  let geomColumn = null;
  try {
    const meta = await parquetMetadata(file);
    const kv = meta && (meta.key_value_metadata || meta.metadata || []);
    const entry = Array.isArray(kv)
      ? kv.find(item => item.key === "geo")
      : (kv instanceof Map ? { value: kv.get("geo") } : null);
    const rawGeo = entry && entry.value;
    const geoText = rawGeo instanceof Uint8Array ? new TextDecoder().decode(rawGeo) : rawGeo;
    const geo = geoText ? JSON.parse(geoText) : null;
    if (geo && geo.primary_column) geomColumn = geo.primary_column;
  } catch {}
  const isGeometryValue = value =>
    value instanceof Uint8Array || (value && typeof value === "object" && typeof value.type === "string" && ("coordinates" in value || "geometries" in value));
  const firstRow = rows[0];
  if (!geomColumn || !(geomColumn in firstRow)) {
    geomColumn = "geometry" in firstRow ? "geometry"
      : Object.keys(firstRow).find(key => isGeometryValue(firstRow[key]));
  }
  if (!geomColumn) throw new Error("ジオメトリ列が見つかりません");
  const features = [];
  for (const row of rows) {
    const value = row[geomColumn];
    const geometry = value instanceof Uint8Array
      ? wkbToGeoJsonGeometry(value)
      : (isGeometryValue(value) ? value : null);
    if (!geometry) continue;
    const properties = {};
    for (const key of Object.keys(row)) {
      if (key === geomColumn) continue;
      properties[key] = sanitizeVectorPropertyValue(row[key]);
    }
    features.push({ type: "Feature", geometry, properties });
  }
  return { type: "FeatureCollection", features };
}

function parseDelimited(text, delim) {
  const lines = text.split(/\r?\n/).filter(l => l.trim());
  if (!lines.length) return [];
  const head = lines[0].split(delim).map(h => h.trim().replace(/^"|"$/g, ""));
  return lines.slice(1).map(line => {
    const cells = line.split(delim).map(c => c.trim().replace(/^"|"$/g, ""));
    const row = {};
    head.forEach((h, i) => { row[h] = cells[i]; });
    return row;
  });
}

function loadCsvLike(text, delim) {
  const rows = parseDelimited(text, delim);
  const sample = rows[0] || {};
  const keys = Object.keys(sample);
  const lonKey = keys.find(k => /^(lon|lng|longitude|x|経度)$/i.test(k)) || keys.find(k => /lon|lng/i.test(k));
  const latKey = keys.find(k => /^(lat|latitude|y|緯度)$/i.test(k)) || keys.find(k => /^lat/i.test(k));
  if (!lonKey || !latKey) throw new Error("経度/緯度列を特定できません");
  const features = [];
  for (const row of rows) {
    const lon = Number(row[lonKey]);
    const lat = Number(row[latKey]);
    if (!Number.isFinite(lon) || !Number.isFinite(lat)) continue;
    const { [lonKey]: _x, [latKey]: _y, ...props } = row;
    features.push({ type: "Feature", geometry: { type: "Point", coordinates: [lon, lat] }, properties: props });
  }
  return { type: "FeatureCollection", features };
}

// FeatureCollection の属性値を一括で正規化する
function sanitizeFeatureCollection(fc) {
  if (!fc || fc.type !== "FeatureCollection" || !Array.isArray(fc.features)) {
    throw new Error("GeoJSON FeatureCollection ではありません");
  }
  for (const feature of fc.features) {
    if (!feature || !feature.geometry) continue;
    const props = feature.properties;
    if (props) for (const key of Object.keys(props)) props[key] = sanitizeVectorPropertyValue(props[key]);
  }
  fc.features = fc.features.filter(f => f && f.geometry);
  return fc;
}

// KML / KMZ → GeoJSON。KMZ(ZIP)は先頭の .kml エントリを展開する。
// @tmcw/togeojson は SimpleData/Style/simplestyle も properties へ写す
async function loadKml(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`kml 取得失敗: ${res.status}`);
  const buf = await res.arrayBuffer();
  const head = new Uint8Array(buf, 0, 2);
  let xmlText;
  if (head[0] === 0x50 && head[1] === 0x4b) {
    const { default: JSZip } = await import(JSZIP_URL);
    const zip = await JSZip.loadAsync(buf);
    const kmlFile = Object.values(zip.files).find(f => !f.dir && /\.kml$/i.test(f.name));
    if (!kmlFile) throw new Error("KMZ 内に .kml がありません");
    xmlText = await kmlFile.async("text");
  } else {
    xmlText = new TextDecoder().decode(buf);
  }
  const dom = new DOMParser().parseFromString(xmlText, "application/xml");
  if (dom.getElementsByTagName("parsererror").length) throw new Error("KML のパースに失敗しました");
  const { kml } = await import(TOGEOJSON_URL);
  return sanitizeFeatureCollection(kml(dom));
}

// Shapefile(.zip 一式 / .shp+sidecar / ベース名URL) → GeoJSON。
// shpjs は URL 文字列を受けると .zip 判定・拡張子補完(sidecar 自動取得)・
// .prj に基づく WGS84 への再投影まで内部で行う
async function loadShp(url) {
  const mod = await import(SHP_URL);
  const shp = mod.default || mod.getShapefile;
  const out = await shp(url);
  // zip に複数レイヤーがある場合は FeatureCollection の配列が返るため統合する
  const fc = Array.isArray(out)
    ? { type: "FeatureCollection", features: out.flatMap(x => (x && x.features) || []) }
    : out;
  return sanitizeFeatureCollection(fc);
}

// OGC WFS → GeoJSON。wfs:タイトル|エンドポイント|typename=名|version=|maxfeatures=|
// cql_filter=|srsname=|outputformat= 。GET の GetFeature(outputFormat=json 系)のみ
async function loadWfs(item, url) {
  const opts = item.opts || {};
  const typeNames = opts.typename || opts.typenames || opts.layer || opts.name;
  if (!typeNames) throw new Error("wfs: typename= の指定が必要です");
  const version = /^\d/.test(opts.version || "") ? opts.version : "2.0.0";
  const build = outputFormat => {
    const params = new URLSearchParams();
    params.set("service", "WFS");
    params.set("request", "GetFeature");
    params.set("version", version);
    params.set(version.startsWith("2") ? "typeNames" : "typeName", typeNames);
    params.set("outputFormat", outputFormat);
    params.set("srsName", opts.srsname || "EPSG:4326");
    const limit = opts.count || opts.maxfeatures;
    if (limit) params.set(version.startsWith("2") ? "count" : "maxFeatures", limit);
    const cql = opts.cql_filter || opts.cqlfilter;
    if (cql) params.set("cql_filter", cql);
    const sep = url.includes("?") ? "&" : "?";
    return `${url}${sep}${params.toString()}`;
  };
  const formats = opts.outputformat
    ? [opts.outputformat]
    : ["application/json", "application/json; subtype=geojson", "geojson", "json"];
  let lastError = null;
  for (const fmt of formats) {
    const res = await fetch(build(fmt));
    if (!res.ok) { lastError = new Error(`WFS GetFeature 失敗: ${res.status}`); continue; }
    const text = await res.text();
    try {
      const json = JSON.parse(text);
      if (json && (json.type === "FeatureCollection" || json.type === "Feature")) {
        return sanitizeFeatureCollection(
          json.type === "Feature" ? { type: "FeatureCollection", features: [json] } : json);
      }
      lastError = new Error("WFS 応答が GeoJSON ではありません");
    } catch {
      lastError = new Error("WFS 応答が GeoJSON ではありません");
    }
  }
  throw lastError || new Error("WFS GetFeature 失敗");
}

const BBOX_OFF_RE = /^(off|none|false|static|manual)$/i;

// 表示範囲連動クエリ(bbox=auto / :bbox プレースホルダ)が有効な行か。
// gpkg:/duckdb: は bbox=off 系の明示指定が無い限り既定で viewport 絞り込み
export function isViewportQueryItem(item) {
  if (!item) return false;
  if (item.type === "sql") return /:bbox\b/i.test(item.url || "");
  if (item.type === "duckdb" || item.type === "gpkg" || item.type === "geopackage") {
    return !BBOX_OFF_RE.test(String(item.opts?.bbox ?? "auto"));
  }
  return false;
}

// sql: 行のクエリ末尾に付く "| off" / "| attr=..." を除去する(kasc_loader.js と同じ規則)
const SQL_TAIL_RE = /\|\s*(off|false|attr(?:ibution)?\s*=[^|]*|cluster\s*=\s*[a-z0-9]+|heat(?:map)?\s*=\s*[a-z0-9]+|render\s*=\s*[a-z]+|style\s*=\s*[^|]*|time(?:_end|_span)?\s*=\s*[^|]*)\s*$/i;
function stripSqlTail(query) {
  let q = String(query || "");
  for (;;) {
    const m = SQL_TAIL_RE.exec(q);
    if (!m) return q;
    q = q.slice(0, m.index).trim();
  }
}

// ---- ogrsql: OGR SQL SELECT 文のクライアント実行(shared/ogr-sql.js) ----

// ファイルパス → loadVectorItem の行タイプ(拡張子判定)
function ogrFileType(path) {
  const clean = String(path || "").split(/[?#]/)[0];
  if (/\.(fgb|flatgeobuf)$/i.test(clean)) return "flatgeobuf";
  if (/\.(parquet|geoparquet)$/i.test(clean)) return "geoparquet";
  if (/\.gpkg$/i.test(clean)) return "gpkg";
  if (/\.(kml)$/i.test(clean)) return "kml";
  if (/\.(kmz)$/i.test(clean)) return "kmz";
  if (/\.(zip|shp|dbf)$/i.test(clean)) return "shp";
  if (/\.tsv$/i.test(clean)) return "tsv";
  if (/\.csv$/i.test(clean)) return "csv";
  return "geojson";
}

// FROM 名 → 候補パス。パスらしい名前(/・拡張子・scheme あり)はそのまま。
// 裸のレイヤー名は DATA/<名>.<形式> を順に試す
function ogrSourceCandidates(name) {
  const n = String(name || "").trim();
  if (!n) return [];
  const looksPath = /[/\\]/.test(n) || /^[a-z][a-z0-9+.-]*:/i.test(n)
    || /\.(geojson|json|fgb|flatgeobuf|parquet|geoparquet|gpkg|kml|kmz|zip|shp|dbf|csv|tsv)$/i.test(n);
  if (looksPath) return [n];
  return [
    `DATA/${n}.geojson`, `DATA/${n}.fgb`, `DATA/${n}.parquet`,
    `DATA/${n}.gpkg`, `DATA/${n}.kml`, `DATA/${n}.csv`, n,
  ];
}

// ogrsql: の FROM 解決リゾルバを作る。戻り値は resolveSource(ref) 関数。
// ref = {name, alias?, source?('ds'.layer 形式のデータソース)}。
// 解決順: resolveLayer フック(読み込み済みレイヤータイトル照合・QGIS 等)
// → 'ds'.layer はファイル+レイヤー名(gpkg table= 等)としてデコード
// → パス/拡張子推測でファイルをデコード
export function createOgrSourceResolver({ baseUrl, bounds = null, resolveLayer = null } = {}) {
  const decodePath = async (path, table) => {
    const it = {
      type: ogrFileType(path),
      title: table || path,
      url: path,
      opts: table ? { table } : {},
    };
    return (await loadVectorItem(it, baseUrl, bounds)).geojson;
  };
  return async ref => {
    if (ref.source) {
      // 'ds'.layer 形式: ファイル + レイヤー名(gpkg の table= 等)
      return decodePath(ref.source, ref.name);
    }
    if (resolveLayer) {
      const fc = await resolveLayer(ref.name);
      if (fc) return fc;
    }
    let lastError = null;
    for (const path of ogrSourceCandidates(ref.name)) {
      try { return await decodePath(path); }
      catch (e) { lastError = e; }
    }
    throw lastError || new Error(`ogrsql: テーブル "${ref.name}" を解決できません`);
  };
}

// parseKasc の item → KascLoader.load 用アイテム（相対参照は絶対URLへ解決済み）
function toKascLoaderItem(item, baseUrl, bounds) {
  const opts = item.opts || {};
  const it = {
    id: `kasc-${Math.random().toString(36).slice(2)}`,
    type: item.type,
    title: item.title,
    visible: item.visible !== false,
    sourceLine: item.line,
    where: opts.where || undefined,
    geom: opts.geom || opts.geometry || undefined,
    lon: opts.lon || opts.lng || undefined,
    lat: opts.lat || undefined,
    format: opts.format || undefined,
    gpkgTable: opts.table || undefined,
    columns: opts.columns ? opts.columns.split(",").map(s => s.trim()).filter(Boolean) : undefined,
    covering: opts.covering ? opts.covering.split(",").map(s => s.trim()).filter(Boolean) : undefined,
    limit: Number.isInteger(Number(opts.limit)) ? Math.floor(Number(opts.limit)) : undefined,
    bboxAuto: isViewportQueryItem(item),
    bboxBounds: null,
  };
  if (it.bboxAuto) it.bboxBounds = bounds || null;
  if (item.type === "sql") {
    // クエリ内の相対ファイル参照をプロジェクト基準の絶対URLへ解決(httpfs経由で読める形に)
    it.query = stripSqlTail(item.url)
      .replace(/'((?:\.\.?\/|DATA\/)[^']+)'/gi, (_, ref) => `'${resolveKascUrl(ref, baseUrl)}'`);
  } else {
    it.url = resolveKascUrl(item.url, baseUrl);
  }
  return it;
}

// item(.kasc 行) → GeoJSON FeatureCollection
// 戻り値: { geojson, qml?, viewportQuery? } （gpkg は埋め込み QML があれば返す。
// viewportQuery=true の行は表示範囲の移動に合わせて再読込が必要）
// hooks.resolveLayer(name) = ogrsql: の FROM 名を読み込み済みレイヤーの
// FeatureCollection へ解決する任意フック(エンジン側のレイヤー照合)
export async function loadVectorItem(item, baseUrl, bounds = null, hooks = null) {
  const url = resolveKascUrl(item.url, baseUrl);
  const type = item.type;
  if (type === "geojson" || type === "layer") {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`${item.title}: ${res.status}`);
    return { geojson: await res.json() };
  }
  if (type === "flatgeobuf" || type === "fgb") {
    return { geojson: await loadFlatGeobuf(url) };
  }
  if (type === "geoparquet" || type === "parquet") {
    return { geojson: await loadGeoParquet(url) };
  }
  if (type === "gpkg" || type === "geopackage") {
    const opts = item.opts || {};
    const viewportQuery = isViewportQueryItem(item);
    const result = await gpkgCommand({
      cmd: "load",
      url,
      table: opts.table,
      where: opts.where,
      limit: opts.limit ? Number(opts.limit) : undefined,
      columns: opts.columns ? opts.columns.split(",").map(s => s.trim()) : undefined,
      bbox: viewportQuery ? bounds || undefined : undefined,
      wantStyle: !!opts.style,
    });
    return { ...result, viewportQuery };
  }
  if (type === "kml" || type === "kmz") {
    return { geojson: await loadKml(url) };
  }
  if (type === "wfs") {
    return { geojson: await loadWfs(item, url) };
  }
  if (type === "shp" || type === "shapefile") {
    return { geojson: await loadShp(url) };
  }
  if (type === "csv" || type === "tsv") {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`${item.title}: ${res.status}`);
    return { geojson: loadCsvLike(await res.text(), type === "tsv" ? "\t" : ",") };
  }
  if (type === "duckdb" || type === "sql") {
    if (!window.KascLoader) await import("./kasc_loader.js");
    const it = toKascLoaderItem(item, baseUrl, bounds);
    const geojson = await window.KascLoader.load(it);
    return { geojson, viewportQuery: it.bboxAuto };
  }
  if (type === "ogrsql") {
    // OGR SQL SELECT 文。主経路はブラウザ内 JS 実装(shared/ogr-sql.js)で、
    // CDN 単体利用でも QGIS 有無で挙動が変わらないよう常に先に実行する。
    // JS で解決できない FROM(QGIS プロジェクトレイヤー・ローカル SHP 等)
    // や JS パーサ未対応の構文だけ、ローカル QGIS Live の GDAL 本体
    // ExecuteSQL(dialect="OGRSQL") へフォールバックする。
    // FROM はレイヤータイトル照合(resolveLayer フック)→ 'ds'.layer 形式
    // → ファイルパス推測の順に解決する
    const query = stripSqlTail(item.url);
    const { executeOgrSelect } = await import("./ogr-sql.js");
    const resolve = createOgrSourceResolver({
      baseUrl, bounds, resolveLayer: hooks?.resolveLayer || null,
    });
    try {
      return { geojson: await executeOgrSelect(query, resolve) };
    } catch (jsErr) {
      const { runOgrSqlViaQgis } = await import("./qgis-ogr.js");
      const viaQgis = await runOgrSqlViaQgis(query, async ref =>
        (!ref.source && hooks?.resolveLayer ? hooks.resolveLayer(ref.name) : null),
        path => resolveKascUrl(path, baseUrl));
      if (viaQgis) return { geojson: viaQgis };
      throw jsErr;
    }
  }
  throw new Error(`未対応のベクター形式: ${type}`);
}
